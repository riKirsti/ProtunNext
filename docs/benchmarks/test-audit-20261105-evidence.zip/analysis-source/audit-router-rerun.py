"""Owned temporary forwarding lab; off-router HTTPS load, no account/package changes."""
import datetime,hashlib,http.client,ipaddress,json,pathlib,re,shlex,socket,ssl,struct,sys,time,traceback
import router_access
BASE=pathlib.Path(__file__).resolve().parent
LABEL='travel-long' if '--long' in sys.argv else 'travel'
OUT=BASE.parent/('outputs/audit-v2/'+LABEL);OUT.mkdir(parents=True,exist_ok=True)
TARGET=json.loads((BASE/'audit-router-private/target.json').read_text())
HOST=TARGET['host'];DEST=str(ipaddress.IPv4Address(TARGET['ip']));LOCAL='192.168.7.169'
CTX=ssl.create_default_context();PORT=20161 if '--long' in sys.argv else 19961
PORT_LOW=20160 if '--long' in sys.argv else 19960
PORT_HIGH=20560 if '--long' in sys.argv else 20160
MEASURE_BYTES=100000000 if '--long' in sys.argv else 12000000

def download(size,cap=60):
 global PORT
 PORT+=1;assert PORT<=PORT_HIGH
 row={'requested_bytes':size,'local_port':PORT,'valid':False};start=time.perf_counter();s=None
 try:
  s=socket.socket();s.settimeout(min(8,cap));s.setsockopt(socket.IPPROTO_IP,31,struct.pack('!I',11));s.bind((LOCAL,PORT));s.connect((DEST,443))
  s=CTX.wrap_socket(s,server_hostname=HOST)
  row.update(local=s.getsockname(),peer=s.getpeername(),tls=s.version())
  s.sendall((f'GET /pub/linux/kernel/v6.x/linux-6.12.112.tar.xz HTTP/1.1\r\nHost: {HOST}\r\nRange: bytes=0-{size-1}\r\nConnection: close\r\n\r\n').encode())
  r=http.client.HTTPResponse(s);r.begin();row.update(status=r.status,content_range=r.getheader('Content-Range'),content_length=r.getheader('Content-Length'))
  assert r.status==206 and re.fullmatch(rf'bytes 0-{size-1}/[0-9]+',row['content_range'] or '')
  buf=bytearray(1024*1024);n=0
  while True:
   remain=cap-(time.perf_counter()-start);assert remain>0,'sample deadline'
   s.settimeout(min(8,remain));got=r.readinto(buf)
   if not got:break
   n+=got;assert n<=size
  row.update(bytes=n,valid=n==size and row['local'][0]==LOCAL and row['peer'][0]==DEST)
 except Exception as e:row.update(error=type(e).__name__+': '+str(e))
 finally:
  if s:s.close()
 row['seconds']=time.perf_counter()-start
 if row['valid']:row['Mbps']=size*8/row['seconds']/1e6
 return row

class Lab:
 def __init__(self):self.c=None;self.stage=None;self.guard=None;self.channel=None;self.worker=None;self.report={'samples':[],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 def save(self):(OUT/'evidence.json').write_text(json.dumps(self.report,indent=2))
 def run(self,cmd,timeout=20):
  _,o,e=self.c.exec_command('HISTFILE=/dev/null; export HISTFILE; '+cmd,timeout=timeout)
  out=o.read().decode(errors='replace');err=e.read().decode(errors='replace');return {'exit':o.channel.recv_exit_status(),'stdout':out,'stderr':err}
 def check(self,cmd,timeout=20):
  r=self.run(cmd,timeout)
  if r['exit']:raise RuntimeError('temporary lab operation failed: '+r['stderr'][-250:])
  return r['stdout']
 def put(self,name,data,mode=0o600):
  assert re.fullmatch('[a-z.]+',name)
  i,o,e=self.c.exec_command('umask 077; cat >'+shlex.quote(self.stage+'/'+name)+'; chmod '+oct(mode)[2:]+' '+shlex.quote(self.stage+'/'+name),timeout=30)
  i.write(data);i.flush();i.channel.shutdown_write();o.read();assert o.channel.recv_exit_status()==0
 def snapshot(self):
  commands={'mode':'uci -q get exitnode.main.mode','identity':'cat /proc/sys/kernel/random/boot_id; pidof netifd','links':'ls -1 /sys/class/net | sort','rules':'ip -4 rule show','default':'ip -4 route show default','packages':'apk info 2>/dev/null | sort','limits':'cat /proc/sys/net/core/rmem_max /proc/sys/net/core/wmem_max','configs':'sha256sum /etc/config/exitnode /etc/config/network /etc/config/firewall /etc/config/dhcp /etc/config/wireless /root/proton-private/active.conf /root/proton-private/active.server /root/proton-private/preferences.json /root/proton-private/transport-ports.json'}
  return {k:self.check(v) for k,v in commands.items()}
 def setup(self):
  self.c=router_access.connect();self.c.get_transport().set_keepalive(10);self.before=self.snapshot();assert self.before['mode'].strip()=='direct'
  assert not re.search(r'^19943:',self.before['rules'],re.M)
  assert not self.run('ip -4 route show table 19943')['stdout'].strip()
  assert '10.2.0.2/' not in self.check('ip -o addr show')
  self.config=self.check('cat /root/proton-private/active.conf')
  def field(key):return re.search(r'^\s*'+key+r'\s*=\s*(.*?)\s*$',self.config,re.M).group(1)
  self.address=field('Address').split(',')[0].strip();assert self.address=='10.2.0.2/32'
  self.mtu=int(field('MTU')) if re.search(r'^MTU\s*=',self.config,re.M) else 1280
  self.endpoint=field('Endpoint');ipaddress.IPv4Address(self.endpoint.rsplit(':',1)[0]);self.udp=int(self.endpoint.rsplit(':',1)[1])
  self.tls=int(json.loads(self.check('cat /root/proton-private/transport-ports.json'))['tls_ports'][0])
  self.stage=self.check('mktemp -d /tmp/pna-audit.XXXXXX').strip();assert re.fullmatch(r'/tmp/pna-audit\.[A-Za-z0-9]+',self.stage)
  self.token='pna'+self.stage.rsplit('.',1)[1];self.ifname=self.token;assert len(self.ifname)<15
  self.start=time.monotonic();self.deadline=self.start+1200
  cleanup=f'''#!/bin/sh
stage={shlex.quote(self.stage)}
for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in "$stage"/*) p=${{f%/exe}}; kill -TERM "${{p##*/}}" 2>/dev/null;; esac; done
sleep 0.2
for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in "$stage"/*) p=${{f%/exe}}; kill -KILL "${{p##*/}}" 2>/dev/null;; esac; done
for h in $(nft -a list chain inet fw4 forward 2>/dev/null | awk -v mark={self.token} 'index($0,mark){{for(i=1;i<NF;i++)if($i=="handle" && $(i+1)~/^[0-9]+$/)print $(i+1)}}'); do nft delete rule inet fw4 forward handle "$h"; done
nft delete table ip {self.token} 2>/dev/null
ip -4 rule del priority 19943 from {LOCAL}/32 to {DEST}/32 ipproto tcp sport 19960-20160 lookup 19943 2>/dev/null
ip -4 route del default dev {self.ifname} table 19943 2>/dev/null
ip link del dev {self.ifname} 2>/dev/null
rm -f "$stage/main" "$stage/erase" "$stage/gro" "$stage/parallel" "$stage/ktls" "$stage/config" "$stage/kernel.conf" "$stage/guard.sh" "$stage/cleanup.sh"
rmdir "$stage"
'''
  cleanup=cleanup.replace('19960-20160',f'{PORT_LOW}-{PORT_HIGH}')
  self.put('cleanup.sh',cleanup.encode())
  self.put('guard.sh',f"sleep 1200\nsh {self.stage}/cleanup.sh\n".encode())
  self.guard=int(self.check(f'nohup sh {self.stage}/guard.sh >/dev/null 2>&1 </dev/null & echo $!').strip())
  self.put('config',self.config.encode())
  self.report.update(stage=self.stage,interface=self.ifname,server=self.check('cat /root/proton-private/active.server').strip(),kernel=self.check('uname -r').strip(),before=self.before,mtu=self.mtu,method='Laptop HTTPS via per-socket IP_UNICAST_IF; benchmark-only router policy/NAT, no Windows routes')
  self.report['binaries']={}
  for name in ['main','erase','gro','parallel','ktls']:
   p=BASE/('audit-ktls-target/aarch64-unknown-linux-musl/release/ktls-next-probe' if name=='ktls' else 'audit-router-binaries/'+name)
   data=p.read_bytes();self.put(name,data,0o700);h=hashlib.sha256(data).hexdigest();assert self.check(f'sha256sum {self.stage}/{name}').split()[0]==h;self.report['binaries'][name]=h
  self.save()
 def line(self,prefix,timeout=20):
  self.worker.channel.settimeout(timeout)
  line=self.worker.readline()
  assert line.startswith(prefix),f'worker protocol: {line[:200]}'
  return line[len(prefix):].strip()
 def stop(self):
  if self.channel:
   try:
    self.input.write('quit\n');self.input.flush();self.report.setdefault('shutdowns',[]).append(self.line('LIVE_FINAL ',10))
   except Exception as e:self.report.setdefault('shutdown_errors',[]).append(str(e))
   self.channel.close();self.channel=None
  if not self.stage:return
  # Same owned cleanup scope as watchdog, retaining staged files until the end.
  script=self.check('cat '+self.stage+'/cleanup.sh').split('rm -f "$stage/main"')[0]
  self.check('sh -c '+shlex.quote(script)+'; true')
 def forward(self):
  self.check(f'ip -4 route add default dev {self.ifname} table 19943')
  self.check(f'ip -4 rule add priority 19943 from {LOCAL}/32 to {DEST}/32 ipproto tcp sport {PORT_LOW}-{PORT_HIGH} lookup 19943')
  rules=f'''add table ip {self.token}
add chain ip {self.token} post {{ type nat hook postrouting priority 95; policy accept; }}
add rule ip {self.token} post oifname "{self.ifname}" ip saddr {LOCAL} ip daddr {DEST} tcp sport 19960-20160 tcp dport 443 snat to 10.2.0.2
insert rule inet fw4 forward iifname "br-lan" oifname "{self.ifname}" ip saddr {LOCAL} ip daddr {DEST} tcp sport 19960-20160 tcp dport 443 counter accept comment "{self.token}-out"
insert rule inet fw4 forward iifname "{self.ifname}" oifname "br-lan" ip saddr {DEST} ip daddr {LOCAL} tcp sport 443 tcp dport 19960-20160 counter accept comment "{self.token}-in"
'''
  rules=rules.replace('19960-20160',f'{PORT_LOW}-{PORT_HIGH}')
  self.check('nft -f - <<\'PNA_RULES\'\n'+rules+'PNA_RULES\n')
 def start_worker(self,build,proto):
  self.stop()
  if build=='kernel':
   # Derive only the wg setconf fields in memory; never log private key content.
   cfg='\n'.join(line for line in self.config.splitlines() if not re.match(r'\s*(Address|MTU|DNS)\s*=',line))+'\n'
   self.put('kernel.conf',cfg.encode())
   self.check(f'ip link add {self.ifname} type wireguard')
   self.check(f'wg setconf {self.ifname} {self.stage}/kernel.conf')
   self.check(f'ip address add {self.address} dev {self.ifname}')
   self.check(f'ip link set {self.ifname} mtu {self.mtu} up')
  else:
   port=self.udp if proto=='udp' else self.tls
   self.input,self.worker,self.error=self.c.exec_command(f'{self.stage}/{build} {self.stage}/config {proto} {self.ifname} eth0 {port}',timeout=20)
   self.channel=self.worker.channel
   stamp=json.loads(self.line('LIVE_READY '));expected=json.loads((BASE/'audit-router-private/live-builds.json').read_text())[build]['effective_sources_sha256'];assert stamp['effective_sources_sha256']==expected
  self.forward()
 def counts(self):
  raw=self.check('nft list chain inet fw4 forward');result={}
  for way in ['in','out']:
   line=next(l for l in raw.splitlines() if self.token+'-'+way in l)
   result[way]=int(re.search(r'counter packets \d+ bytes (\d+)',line).group(1))
  return result
 def sample(self,build,proto,role,slot,size):
  assert time.monotonic()+85<self.deadline,'insufficient remaining test budget'
  row={'build':build,'protocol':proto,'role':role,'slot':slot,'size':size};self.report['samples'].append(row);self.save()
  try:
   self.start_worker(build,proto)
   row['warmups']=[];warm_start=time.perf_counter()
   for attempt in range(3 if '--long' in sys.argv else 1):
    row['warmups'].append(download(12000000 if '--long' in sys.argv else 262144,12))
    if row['warmups'][-1]['valid'] and time.perf_counter()-warm_start>=1:break
   if not row['warmups'][-1]['valid']:
    row['warmup_forward_counts']=self.counts()
    if build=='kernel':row['kernel_diagnostics']=self.check(f'wg show {self.ifname} latest-handshakes; wg show {self.ifname} transfer; ip -4 route get {DEST} from {LOCAL} iif br-lan ipproto tcp sport {PORT} dport 443')
    elif self.channel:self.input.write('state\n');self.input.flush();row['warmup_state']=json.loads(self.line('LIVE_STATE '))
    raise RuntimeError('warmup failed')
   before=self.counts();row['system_before']=self.check('head -n 1 /proc/stat')
   if self.channel:self.input.write('start\n');self.input.flush();self.line('LIVE_START')
   row['download']=download(size,60)
   if self.channel:
    self.input.write('stop\n');self.input.flush();row['worker']=json.loads(self.line('LIVE_METRICS '))
   row['system_after']=self.check('head -n 1 /proc/stat');after=self.counts();row['forwarded_bytes']={k:after[k]-before[k] for k in before}
   row['valid']=row['download']['valid'] and row['forwarded_bytes']['in']>=size and row['forwarded_bytes']['out']>0
   if build=='kernel':row['kernel_handshake']=int(self.check('wg show '+self.ifname+' latest-handshakes').split()[-1])>0;row['valid'] &= row['kernel_handshake']
   if row['valid'] and 'worker'in row:row['cpu_ns_per_byte']=row['worker']['process_cpu_ns']/size
  except Exception as e:row.update(valid=False,error=type(e).__name__+': '+str(e))
  finally:self.stop();self.save()
  print(json.dumps({k:row[k]for k in ['build','protocol','role','slot','valid','error','download']if k in row}),flush=True)
 def close(self):
  if not self.c:return
  try:
   self.stop()
   if self.stage:
    self.run('sh '+self.stage+'/cleanup.sh')
    if self.guard and self.stage+'/guard.sh' in self.run(f'tr "\\0" " " </proc/{self.guard}/cmdline')['stdout']:self.run('kill -TERM '+str(self.guard))
    after=self.snapshot();self.report['cleanup']={k:after[k]==v for k,v in self.before.items()};self.report['cleanup']['stage_absent']=self.run('test ! -e '+self.stage)['exit']==0
    self.report['cleanup']['firewall_owned_rules_absent']=self.token not in self.check('nft list ruleset')
    self.report['elapsed_seconds']=time.monotonic()-self.start
    self.save();print(json.dumps({'cleanup':self.report['cleanup'],'elapsed_seconds':self.report['elapsed_seconds']}),flush=True)
  finally:self.c.close();self.config=''

if __name__=='__main__':
 lab=Lab()
 try:
  lab.setup()
  lab.report['ktls_functional']=lab.run(lab.stage+'/ktls',20);lab.save();print(json.dumps({'ktls_functional':lab.report['ktls_functional']}),flush=True)
  if '--ktls-only' not in sys.argv:
   lab.report['direct_before']=download(12000000);lab.save()
   # Predeclared 12 MB files, identical size in every comparison, two A/two B.
   # This is a WAN validation, not an isolated throughput ceiling measurement.
   for proto in ['udp','tcp','stealth']:
    for role,order in [('aa',['main']*4),('erasure',['main','erase','erase','main']),('parallel',['erase','parallel','parallel','erase'])]:
     for slot,build in enumerate(order):lab.sample(build,proto,role,slot,MEASURE_BYTES)
   for role,order in [('gro',['erase','gro','gro','erase']),('kernel',['erase','kernel','kernel','erase'])]:
    for slot,build in enumerate(order):lab.sample(build,'udp',role,slot,MEASURE_BYTES)
   lab.report['direct_after']=download(12000000);lab.save()
 except BaseException as e:
  lab.report['fatal']=type(e).__name__+': '+str(e);lab.save();traceback.print_exc()
 finally:lab.close()
