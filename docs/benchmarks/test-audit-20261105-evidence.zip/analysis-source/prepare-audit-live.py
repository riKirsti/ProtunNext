import hashlib,json,pathlib,shutil,subprocess,sys
base=pathlib.Path(__file__).resolve().parent
root=base/'ProtunNext'
subprocess.run([sys.executable,str(root/'experiments/audit/prepare.py')],check=True,stdout=subprocess.DEVNULL)
state=json.loads((root/'target/audit-v2/builds.json').read_text())
live={}
for name in ['main','erase','gro','parallel']:
 row=state[name]; dest=pathlib.Path(row['path'])
 shutil.copyfile(root/'experiments/audit/live.rs',dest/'src/audit_live.rs')
 f=dest/'src/lib.rs'; f.write_text(f.read_text()+'\n#[cfg(target_os="linux")] pub mod audit_live;\n')
 (dest/'src/bin/audit-live.rs').write_text('fn main(){protun_next::audit_live::run();}\n')
 f=dest/'Cargo.toml';f.write_text(f.read_text()+'\n[[bin]]\nname="audit-live"\npath="src/bin/audit-live.rs"\n')
 h=hashlib.sha256()
 for f in sorted([*dest.rglob('*.rs'),*dest.rglob('Cargo.toml'),*dest.rglob('Cargo.lock')]):
  h.update(f.relative_to(dest).as_posix().encode()+b'\0'+f.read_bytes().replace(b'\r\n',b'\n')+b'\0')
 row['effective_sources_sha256']=h.hexdigest();live[name]=row
(base/'audit-router-private/live-builds.json').write_text(json.dumps(live,indent=2))
print('Prepared four independently stamped live drivers')
