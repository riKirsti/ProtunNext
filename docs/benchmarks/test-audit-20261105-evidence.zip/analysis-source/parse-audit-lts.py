import json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1];folder=ROOT/'outputs/worker-next-20261105/audit-v2-lts-final'
text=(folder/'guest.log').read_text();assert 'AUDIT_KERNEL 6.18.60'in text and 'AUDIT_EXIT 0'in text
sources=json.loads((folder/'builds.json').read_text());rows=[];current=None
def finish():
 if current:
  assert len(current['metrics'])==1,current
  rows.append(current.copy())
for line in text.splitlines():
 if line.startswith('AUDIT_CASE '):
  finish();case=json.loads(line[11:]);role=case['role'];slot=case['slot']
  current=dict(sample=len(rows)+1,build=case['build'],protocol='stealth',size=case['size'],window=case['window'],flows=case['flows'],shape=case['shape'],rate_pps=0,resources='two',peer_vectored=True,role=('aa-a'if slot in[0,3]else'aa-b')if role=='aa'else'compare-ktls',block=f"{case['repeat']}-{case['shape']}-{case['flows']}-{case['size']}",slot=slot,exit=0,status='completed',stdout='',stderr='',metrics=[])
 elif current:
  current['stdout']+=line+'\n'
  if line.startswith('NEXT_JSON '):current['metrics'].append(json.loads(line[10:]))
finish();assert len(rows)==96
(folder/'samples.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in rows))
# Source stamps and build logs were recorded. Binary/kernel image digests were
# not exported by this fixture; do not invent or mislabel source hashes as them.
(folder/'environment.json').write_text(json.dumps(dict(sources=sources,kernel='6.18.60',machine='x86_64',binaries=None,binary_hashes_recorded=False,allocations=1,repeats_within_allocation=3),indent=2))
print('Parsed 96 actual 6.18 samples; source identities checked by common analyzer')
