#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <string.h>
int main(int argc,char **argv) {
 if(argc<2)return 2;
 if(unshare(CLONE_NEWNET)){perror("unshare");return 77;}
 int fd=socket(AF_INET,SOCK_DGRAM,0);if(fd<0)return 3;
 struct ifreq req={0};strcpy(req.ifr_name,"lo");
 if(ioctl(fd,SIOCGIFFLAGS,&req)){perror("get lo flags");return 4;}
 req.ifr_flags|=IFF_UP;
 if(ioctl(fd,SIOCSIFFLAGS,&req)){perror("set lo up");return 5;}
 close(fd);execvp(argv[1],argv+1);perror("exec test");return 6;
}
