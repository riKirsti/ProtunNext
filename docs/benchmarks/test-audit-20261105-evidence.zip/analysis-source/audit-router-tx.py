"""Fixed-rate TX-sensitive audit in an owned network namespace, not a WAN ceiling."""
import hashlib,json,pathlib,re,shlex,time,sys
import router_access
BASE=pathlib.Path(__file__).resolve().parent;OUT=BASE.parent/('outputs/audit-v2/travel-tx-aa'if '--aa-only'in sys.argv else'outputs/audit-v2/travel-tx');OUT.mkdir(parents=True,exist_ok=True)
c=router_access.connect();stage=None;guard=None;report={'samples':[],'target_pps':1000,'client_cpus':[0,1],'peer_cpu':0,'generator_cpu':0,'scope':'fixed-rate TX CPU cost; two router cores shared, never a throughput ceiling comparison'}
def save():(OUT/'evidence.json').write_text(json.dumps(report,indent=2))
def run(cmd,timeout=20):
 _,o,e=c.exec_command(cmd,timeout=timeout);out=o.read().decode();err=e.read().decode();return dict(exit=o.channel.recv_exit_status(),stdout=out,stderr=err)
def put(name,data):
 i,o,e=c.exec_command('umask 077; cat >'+stage+'/'+name+'; chmod 700 '+stage+'/'+name,timeout=30);i.write(data);i.flush();i.channel.shutdown_write();o.read();assert o.channel.recv_exit_status()==0
commands={'mode':'uci -q get exitnode.main.mode','configs':'sha256sum /etc/config/exitnode /etc/config/network /etc/config/firewall /etc/config/dhcp /etc/config/wireless /root/proton-private/active.conf /root/proton-private/preferences.json','packages':'apk info | sort','rules':'ip -4 rule show','default':'ip -4 route show default','links':'ls -1 /sys/class/net | sort','identity':'cat /proc/sys/kernel/random/boot_id; pidof netifd'}
before={k:run(v)['stdout'] for k,v in commands.items()};assert before['mode'].strip()=='direct'
try:
 stage=run('mktemp -d /tmp/pna-tx.XXXXXX')['stdout'].strip();assert re.fullmatch(r'/tmp/pna-tx\.[A-Za-z0-9]+',stage)
 cleanup=f'''for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in {stage}/*) p=${{f%/exe}}; kill -KILL "${{p##*/}}" 2>/dev/null;; esac; done
rm -f {stage}/erase {stage}/parallel {stage}/nsrun {stage}/cleanup.sh {stage}/phase.log
rmdir {stage}
'''
 put('cleanup.sh',cleanup.encode());guard=int(run('nohup sh -c '+shlex.quote('sleep 240; sh '+stage+'/cleanup.sh')+' >/dev/null 2>&1 </dev/null & echo $!')['stdout'].strip())
 report['binary_sha256']={};report['sources']=json.loads((BASE/'audit-router-private/probe-builds.json').read_text())
 for name in ['erase','parallel','nsrun']:
  path=BASE/('travel-decision-binaries/nsrun' if name=='nsrun' else 'audit-router-binaries/probe-'+name);data=path.read_bytes();put(name,data);h=hashlib.sha256(data).hexdigest();assert run('sha256sum '+stage+'/'+name)['stdout'].split()[0]==h;report['binary_sha256'][name]=h
 for proto in ['udp','tcp','stealth']:
  for slot,build in enumerate(['erase']*4 if '--aa-only'in sys.argv else ['erase','parallel','parallel','erase']):
   cmd=f'NEXT_PEER_CPUS=0 NEXT_LOAD_CPUS=0 NEXT_CLIENT_CPUS=0,1 NEXT_RATE_PPS=1000 NEXT_WARM_SECONDS=1 NEXT_LOAD_SHAPE=burst {stage}/nsrun {stage}/{build} client {stage}/erase {proto} 1200 32 5 1'
   i,o,e=c.exec_command(cmd,timeout=20);time.sleep(2)
   # Read only our active client tasks, proving whether crypto workers accrue CPU.
   task=run(f'''for p in /proc/[0-9]*; do x=$(readlink "$p/exe" 2>/dev/null); if [ "$x" = "{stage}/{build}" ]; then args=$(tr '\\0' ' ' <"$p/cmdline"); case "$args" in *" client "*) for d in "$p"/task/*; do cat "$d/comm"; cat "$d/stat"; done;; esac; fi; done''')['stdout']
   stdout=o.read().decode();stderr=e.read().decode();code=o.channel.recv_exit_status();metrics=[json.loads(l[10:])for l in stdout.splitlines() if l.startswith('NEXT_JSON ')]
   row=dict(build=build,protocol=proto,slot=slot,exit=code,stdout=stdout,stderr=stderr,tasks_mid_sample=task,metrics=metrics)
   row['valid']=code==0 and len(metrics)==1
   if row['valid']:
    m=metrics[0];row['valid'] &= m['effective_sources_sha256']==report['sources'][build]['effective_sources_sha256'] and m['counters']['invalid_packets']==0
    row['achieved_pps']=m['load']['packets']/m['load']['seconds'];row['rate_achieved']=abs(row['achieved_pps']/1000-1)<.05
    row['aux_combined_cores']=m['load']['cpu_seconds']/m['load']['seconds']+m['peer']['cpu_seconds']/m['peer']['seconds']
   report['samples'].append(row);save();print(json.dumps({k:row[k]for k in ['build','protocol','slot','valid','achieved_pps','rate_achieved','aux_combined_cores']if k in row}),flush=True)
finally:
 if stage:
  run('sh '+stage+'/cleanup.sh')
  if guard and stage+'/cleanup.sh' in run(f'tr "\\0" " " </proc/{guard}/cmdline')['stdout']:
   run(f'for child in $(cat /proc/{guard}/task/{guard}/children); do kill -TERM "$child" 2>/dev/null; done; kill -TERM {guard} 2>/dev/null; true')
  after={k:run(v)['stdout'] for k,v in commands.items()};report['cleanup']={k:after[k]==v for k,v in before.items()};report['cleanup']['stage_absent']=run('test ! -e '+stage)['exit']==0
 save();print(json.dumps({'cleanup':report.get('cleanup')}),flush=True);c.close()
