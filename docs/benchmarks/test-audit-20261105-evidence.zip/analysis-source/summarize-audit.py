import collections,json,math,pathlib,statistics
R=pathlib.Path(__file__).resolve().parents[1];r=json.loads((R/'outputs/audit-v2/full-analysis.json').read_text());assert len(r['allocations'])==6 and not r['failures']
assert collections.Counter(a['arch']for a in r['allocations'])=={'aarch64':3,'x86_64':3}
hosts=[]
for a in r['allocations']:
 assert a['samples']==a['valid']==314
 folder=pathlib.Path(a['folder']);hosts.append((folder/'hardware.txt').read_text().splitlines()[0].split()[1])
 assert len(a['binaries'])==len(set(a['binaries'].values()))==5
# Hosted images repeat their baked-in hostname. Use actual concurrent runner
# allocations from GitHub metadata, never hostname uniqueness as a proxy.
jobs=json.loads((R/'outputs/audit-v2/job-provenance.json').read_text())
assert len(jobs)==len({j['runner_id']for j in jobs})==6 and all(j['conclusion']=='success'for j in jobs)
def aggregate(bs):
 out={}
 for metric in ['Mbps','CPU_ns_per_byte']:
  vals=[b['delta'][metric]for b in bs]
  out[metric]={'geomean_percent':100*(math.exp(statistics.mean(math.log(1+v/100)for v in vals))-1),'allocation_min_percent':min(vals),'allocation_max_percent':max(vals)}
 out.update(allocations=len(bs),AA_pass=sum(bool(b['aa']and b['aa']['passes'])for b in bs),capacity_eligible=sum(b['capacity_ranking_eligible']for b in bs),aux_saturated=sum(b['aux_saturated']for b in bs));return out
groups=collections.defaultdict(list)
for b in r['blocks']:
 if b['role']=='aa':continue
 key=(b['arch'],b['role'],b['block']if b['role']=='peer-writev-sensitivity'else None,*b['case'].values())
 groups[key].append(b)
summary={'samples':1884,'timed_samples':1848,'smoke_samples':36,'allocations':6,'AA_pass':88,'AA_total':90,'all_workloads':[],'bulk_burst':[],'noisy_controls':[]}
for bs in groups.values():
 assert len(bs)==3
 b=bs[0];row=dict(arch=b['arch'],role=b['role'],block=b['block'],case=b['case'],result=aggregate(bs));summary['all_workloads'].append(row)
 c=b['case']
 if c['size']==1200 and c['window']==32 and c['flows']==1 and c['shape']=='burst' and c['rate_pps']==0 and c['resources']=='two' and b['role'].startswith('compare-'):summary['bulk_burst'].append(row)
for b in r['blocks']:
 if b['role']=='aa'and not b['aa']['passes']:summary['noisy_controls'].append(dict(arch=b['arch'],allocation=b['allocation'],case=b['case'],control=b['aa']))
(R/'outputs/audit-v2/summary.json').write_text(json.dumps(summary,indent=2))
for row in summary['bulk_burst']:
 print(row['arch'],row['role'],row['case']['protocol'],{k:round(v['geomean_percent'],2)for k,v in row['result'].items()if isinstance(v,dict)},'eligible',row['result']['capacity_eligible'])
print('All six full allocations and identities validated; noisy sparse controls retained')
