# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +4.40% | -5.70% | -1.48% | True |
| udp-1 | usable | +8.77% | -8.30% | -1.65% | True |
| udp-2 | usable | +0.00% | -12.17% | -2.40% | False |
| tcp-0 | usable | -1.26% | -3.43% | +10.21% | True |
| tcp-1 | usable | +6.00% | -6.11% | -1.80% | True |
| tcp-2 | usable | +0.00% | -9.61% | -3.81% | False |
| stealth-0 | usable | -1.43% | -2.20% | +2.68% | True |
| stealth-1 | usable | +3.98% | -5.01% | +4.57% | True |
| stealth-2 | usable | -0.00% | -8.21% | -2.17% | False |
