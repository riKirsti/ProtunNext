# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +12.66% | -7.04% | +2.02% | True |
| udp-1 | usable | +8.13% | -8.49% | +1.61% | True |
| udp-2 | usable | -0.00% | -4.54% | +5.08% | False |
| tcp-0 | usable | +7.57% | -5.66% | -0.81% | True |
| tcp-1 | usable | +4.29% | -5.33% | -1.03% | True |
| tcp-2 | usable | +0.00% | -11.39% | +0.39% | False |
| stealth-0 | usable | +6.43% | -7.57% | +1.59% | True |
| stealth-1 | usable | +1.45% | -3.59% | -1.88% | True |
| stealth-2 | usable | +0.00% | -3.41% | -2.99% | False |
