# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +2.62% | -7.84% | +1.52% | True |
| udp-1 | usable | +9.49% | -8.56% | +2.85% | True |
| udp-2 | usable | -0.00% | -3.28% | +3.46% | False |
| tcp-0 | usable | +4.21% | -6.73% | +0.61% | True |
| tcp-1 | usable | +3.95% | -3.69% | +1.04% | True |
| tcp-2 | usable | -0.00% | -7.30% | +0.89% | False |
| stealth-0 | usable | +3.14% | -5.45% | +0.96% | True |
| stealth-1 | usable | +3.43% | -4.07% | +1.55% | True |
| stealth-2 | usable | -0.00% | -9.18% | -1.38% | False |
