# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +3.98% | -6.18% | +2.57% | True |
| udp-1 | usable | +12.26% | -10.87% | -1.54% | False |
| udp-2 | usable | +0.00% | -8.19% | +0.73% | False |
| tcp-0 | usable | -0.94% | -4.44% | +0.60% | True |
| tcp-1 | usable | +8.15% | -7.44% | +6.54% | False |
| tcp-2 | usable | +0.00% | -7.25% | -5.07% | False |
| stealth-0 | usable | +0.61% | -4.69% | -0.07% | True |
| stealth-1 | usable | +2.69% | -4.08% | +0.98% | True |
| stealth-2 | usable | -0.00% | -2.25% | -2.08% | False |
