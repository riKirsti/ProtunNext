# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +3.37% | -6.05% | -1.79% | True |
| udp-1 | usable | +11.73% | -10.48% | -5.08% | False |
| udp-2 | usable | -0.00% | -11.06% | -0.22% | False |
| tcp-0 | usable | -0.11% | -4.28% | -1.98% | True |
| tcp-1 | usable | +8.37% | -7.61% | +1.11% | False |
| tcp-2 | usable | +0.00% | -7.75% | +0.19% | False |
| stealth-0 | usable | +1.60% | -6.07% | +2.17% | True |
| stealth-1 | usable | +3.20% | -4.32% | +2.25% | True |
| stealth-2 | usable | -0.00% | -9.03% | +0.02% | False |
