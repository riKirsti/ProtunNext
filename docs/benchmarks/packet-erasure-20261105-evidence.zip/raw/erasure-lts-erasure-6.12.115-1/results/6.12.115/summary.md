# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +0.06% | -6.89% | +3.83% | True |
| udp-1 | usable | +6.85% | -9.71% | -4.32% | True |
| udp-2 | usable | -0.00% | -7.16% | -0.39% | False |
| tcp-0 | usable | -1.69% | -4.80% | +11.46% | True |
| tcp-1 | usable | +1.02% | -5.62% | +5.12% | True |
| tcp-2 | usable | +0.00% | -5.56% | +0.51% | False |
| stealth-0 | usable | +0.26% | -4.17% | +0.50% | True |
| stealth-1 | usable | +0.75% | -5.09% | -3.18% | True |
| stealth-2 | usable | -0.00% | -5.22% | +3.18% | False |
