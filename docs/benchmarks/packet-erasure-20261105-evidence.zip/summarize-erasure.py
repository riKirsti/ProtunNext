import collections
import argparse
import hashlib
import json
import math
import pathlib
import statistics
import sys

root = pathlib.Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--repository', type=pathlib.Path, default=root / 'work/ProtunNext')
parser.add_argument('--input', type=pathlib.Path, default=root / 'outputs/worker-next-20261105')
parser.add_argument('--output', type=pathlib.Path, default=root / 'outputs/erasure-final')
args = parser.parse_args()
repo = args.repository
sys.path.insert(0, str(repo / 'experiments/audit'))
from analyze import analyze

folders = sorted(args.input.glob('erasure-lts-*'))
out = args.output
out.mkdir(parents=True, exist_ok=True)
reports = []
groups = collections.defaultdict(list)
for folder in folders:
    env = next(folder.rglob('environment.json')).parent
    r = analyze(env)
    assert not r['errors'], (folder, r['errors'])
    assert r['observed_samples'] == r['expected_samples'] == 72
    r['allocation'] = folder.name
    reports.append(r)
    for b in r['blocks']:
        groups[(r['environment']['kernel'], b['protocol'], b['shape'], b['rate_pps'])].append(dict(b, allocation=folder.name))
assert len(reports) == 6, len(reports)
summary = dict(samples=sum(r['observed_samples'] for r in reports),
               controls_passed=sum(b['AA_pass'] for r in reports for b in r['blocks']),
               controls_total=sum(len(r['blocks']) for r in reports),
               reports=reports, groups=[])
blocks = [b for r in reports for b in r['blocks']]
unlimited = [b for b in blocks if not b['rate_pps']]
cpu = [b['result']['CPU_ns_per_byte']['change_percent'] for b in blocks]
speed = [b['result']['Mbps']['change_percent'] for b in unlimited]
capacity = sum(b['capacity_ranking'] for b in unlimited)
drift = {k:max(abs(b['control'][k]['change_percent']) for b in blocks) for k in ['Mbps','CPU_ns_per_byte']}
assert all(len({r['environment']['binaries'][name] for r in reports}) == 1 for name in ['main','erase'])
assert all(r['environment']['sources']['erase']['sha'] == '9b469d5f20e35e5f63ff60f579ed9d5a87403206' for r in reports)
assert all('rustc 1.99.1' in r['environment']['compiler'] for r in reports)
lines = ['# Focused packet-erasure results', '',
         f"{summary['samples']} valid samples; {summary['controls_passed']}/{summary['controls_total']} A/A controls passed; zero invalid-data errors. Three independent runner allocations per actual kernel. {sum(x<0 for x in cpu)}/{len(cpu)} comparison blocks reduced measured client CPU/byte (individual changes: {min(cpu):+.2f}% to {max(cpu):+.2f}%).", '',
         'Recommendation: merge the packet-erasure change. It preserves wipe coverage and lowers client CPU cost. Retain rejected backends as research; these measurements justify no new production backend.', '',
         'Each row is the geometric mean across all three allocations; no noisy or limited allocation is silently filtered. CPU % is one process CPU second per wall second = 100%; CPU/byte is the efficiency measure. RSS is lifetime peak client memory, excluding peers and kernel memory. Allocations are unchanged: small RSS variations do not establish a memory gain or regression.', '',
         'These are warmed local UDP echo worker tests through actual Connection/TUN/WireGuard and the selected outer transport, not Proton WAN downloads. They cover 1,200-byte packets, one flow and a 32-packet window. The fixed-rate 10,000 pps cells intentionally transfer 96 Mbps and measure cost at matched load.', '',
         f"{capacity}/{len(unlimited)} unlimited comparison blocks qualify for a capacity ranking. {sum(b['auxiliary_limited'] for b in unlimited)} blocks had peer/generator saturation; their observed throughput is retained but is not a tunnel capacity result. Across all individual unlimited blocks, throughput changes ranged from {min(speed):+.2f}% to {max(speed):+.2f}%, rather than improving in every block. A/A absolute drift reached {drift['Mbps']:.2f}% in throughput and {drift['CPU_ns_per_byte']:.2f}% in CPU/byte (predeclared limit: 5%).", '',
         'Host CPUs differ (Xeon 8370C, EPYC 7763 and EPYC 9V74), so absolute figures must not be used as a causal comparison between kernel versions. The baseline and candidate executable hashes each reproduce identically across all six allocations. Compiler: Rust 1.99.1; normal thin-LTO release; baseline c4b2554, candidate 9b469d5.', '',
         '| Actual x64 kernel | Transport | Load | A/A passed | Mbps main → erase | CPU ns/B main → erase (delta) | CPU % main → erase | Peak RSS MiB main → erase | Capacity-eligible blocks |',
         '|---|---|---|---|---:|---:|---:|---:|---:|']
gm = lambda v: math.exp(statistics.mean(math.log(x) for x in v))
for key, blocks in sorted(groups.items()):
    assert len(blocks) == 3
    # All three allocations are shown, including noise; never silently filter.
    metrics = {}
    for metric in ['Mbps', 'CPU_ns_per_byte', 'CPU_core_percent', 'peak_RSS_MiB']:
        a = gm([b['result'][metric]['baseline'] for b in blocks])
        c = gm([b['result'][metric]['candidate'] for b in blocks])
        metrics[metric] = dict(baseline=a, candidate=c, change_percent=(c / a - 1) * 100,
                               per_allocation_changes=[b['result'][metric]['change_percent'] for b in blocks])
    item = dict(kernel=key[0], protocol=key[1], shape=key[2], rate_pps=key[3],
                AA_pass=sum(b['AA_pass'] for b in blocks), usable=sum(b['validity']=='usable' for b in blocks),
                capacity_eligible=sum(b['capacity_ranking'] for b in blocks), metrics=metrics, blocks=blocks)
    summary['groups'].append(item)
    cells = [f"{metrics[m]['baseline']:.2f} → {metrics[m]['candidate']:.2f}" for m in metrics]
    cells[1] += f" ({metrics['CPU_ns_per_byte']['change_percent']:+.2f}%)"
    lines.append(f"| {key[0]} | {key[1]} | {key[2]} / {key[3] or 'unlimited'} pps | {item['AA_pass']}/3 | {' | '.join(cells)} | {item['capacity_eligible']}/3 |")
(out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
(out / 'summary.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['samples','controls_passed','controls_total']}))
print('\n'.join(lines))
