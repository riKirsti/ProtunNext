INVALID PERFORMANCE COMPARISON

Cargo reused the baseline executable across source archives sharing one target directory. All variant binary hashes are identical in environment.json. Retain as an A/A noise check only. Do not attribute any throughput, latency or CPU difference to GRO or erasure changes. Baseline profiles still describe the baseline binary. Corrected builds use separate target directories plus runtime effective-source identity assertions.
