"""Summarize only explicitly listed PR4 artifacts; never modify raw evidence."""
import collections
import argparse
import json
import math
import pathlib
import statistics
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--repository', type=pathlib.Path, default=ROOT / 'work/ProtunNext')
parser.add_argument('--data-root', type=pathlib.Path, default=ROOT / 'outputs/worker-next-20261105')
parser.add_argument('--output', type=pathlib.Path, default=ROOT / 'outputs/pr4-tls-erasure')
parser.add_argument('--manifest', type=pathlib.Path)
args = parser.parse_args()
sys.path.insert(0, str(args.repository / "experiments/audit"))
from analyze import analyze

OUT = args.output
OUT.mkdir(parents=True, exist_ok=True)
manifest = json.loads((args.manifest or OUT / "artifacts.json").read_text())
reports, groups = [], collections.defaultdict(list)
for artifact in manifest:
    if artifact["run"] != 42104739688:
        continue
    folder = args.data_root / artifact["label"]
    result = analyze(next(folder.rglob("environment.json")).parent)
    assert result["observed_samples"] == result["expected_samples"] == 72 and not result["errors"]
    env = result["environment"]
    assert env["sources"]["main"]["sha"] == "ae9c9e86da8509261812813c9438e7ea625e19f5"
    assert env["sources"]["erase"]["sha"] == "0dff6615a98e62397817783e8b60a0cef68afe0e"
    result["allocation"] = artifact["label"]
    result["artifact"] = artifact["id"]
    reports.append(result)
    for block in result["blocks"]:
        groups[(env["machine"], env["kernel"], block["protocol"], block["shape"], block["rate_pps"])].append(block)
assert len(reports) == 9, len(reports)
blocks = [b for r in reports for b in r["blocks"]]
summary = dict(samples=sum(r["observed_samples"] for r in reports), controls_passed=sum(b["AA_pass"] for b in blocks),
               controls_total=len(blocks), reports=reports, cells=[])
gm = lambda values: math.exp(statistics.mean(math.log(v) for v in values))
lines = ["# PR4 TLS buffer-erasure results", "",
         f"{summary['samples']} valid timed samples; {summary['controls_passed']}/{len(blocks)} A/A controls passed. Baseline: merged PR3 ae9c9e8. Candidate: 0dff661. Fixed, independently identified baseline peer/generator.", "",
         "The only production change is reusing the existing bulk-erasure helper for TLS byte buffers. UDP/TCP are controls; no new UDP/TCP optimization is claimed. Reported figures are local UDP echo worker measurements, not inner TCP/HTTPS or Proton WAN download results.", "",
         "Rows retain all three allocations, including any inconclusive or auxiliary-limited cells. Geometric means are shown. CPU % is client process core utilization; CPU/byte measures efficiency. RSS is lifetime client peak, not total system memory. Allocations remain unchanged. Native ARM64 records the actual host kernel and is not ARM64 supported-LTS acceptance. Host CPU models differ; absolute results are not causal kernel comparisons.", "",
         "| Target / actual kernel | Transport | Load | Usable | Mbps baseline → candidate | CPU ns/B baseline → candidate (delta) | CPU % baseline → candidate | Peak RSS MiB baseline → candidate | Capacity eligible |",
         "|---|---|---|---:|---:|---:|---:|---:|---:|"]
for key, cell in sorted(groups.items()):
    assert len(cell) == 3
    values = {}
    for name in ["Mbps", "CPU_ns_per_byte", "CPU_core_percent", "peak_RSS_MiB"]:
        a = gm([b["result"][name]["baseline"] for b in cell])
        c = gm([b["result"][name]["candidate"] for b in cell])
        values[name] = dict(baseline=a, candidate=c, change_percent=(c / a - 1) * 100,
                            allocation_changes=[b["result"][name]["change_percent"] for b in cell])
    item = dict(machine=key[0], kernel=key[1], protocol=key[2], shape=key[3], rate_pps=key[4],
                usable=sum(b["validity"] == "usable" for b in cell), capacity=sum(b["capacity_ranking"] for b in cell),
                metrics=values, blocks=cell)
    summary["cells"].append(item)
    cells = [f"{values[m]['baseline']:.2f} → {values[m]['candidate']:.2f}" for m in values]
    cells[1] += f" ({values['CPU_ns_per_byte']['change_percent']:+.2f}%)"
    lines.append(f"| {key[0]} / {key[1]} | {key[2]} | {key[3]} / {key[4] or 'unlimited'} pps | {item['usable']}/3 | {' | '.join(cells)} | {item['capacity']}/3 |")
(OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
(OUT / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({k: summary[k] for k in ["samples", "controls_passed", "controls_total"]}))
