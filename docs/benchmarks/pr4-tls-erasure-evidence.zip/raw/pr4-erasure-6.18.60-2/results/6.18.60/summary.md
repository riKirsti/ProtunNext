# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | -3.00% | +3.91% | -3.65% | True |
| udp-1 | usable | +0.30% | -0.29% | -5.88% | True |
| udp-2 | usable | -0.00% | +2.66% | -0.26% | False |
| tcp-0 | usable | -1.82% | +1.53% | -3.33% | True |
| tcp-1 | usable | -0.59% | +0.48% | +2.74% | True |
| tcp-2 | usable | -0.00% | -3.33% | +7.18% | False |
| stealth-0 | usable | +6.23% | -7.42% | -4.32% | True |
| stealth-1 | usable | +4.79% | -4.35% | -1.97% | True |
| stealth-2 | inconclusive-control/load | -0.00% | -5.39% | -1.21% | False |
