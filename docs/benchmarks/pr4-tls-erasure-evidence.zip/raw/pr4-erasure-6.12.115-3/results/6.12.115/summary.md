# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | -5.40% | +3.05% | -0.66% | True |
| udp-1 | usable | +1.03% | -1.09% | +0.62% | True |
| udp-2 | usable | +0.00% | +0.04% | +2.61% | False |
| tcp-0 | usable | -0.74% | -2.51% | +5.35% | True |
| tcp-1 | usable | +0.96% | -0.89% | -3.75% | True |
| tcp-2 | usable | +0.00% | -0.07% | +2.39% | False |
| stealth-0 | usable | +0.44% | -2.55% | -2.51% | True |
| stealth-1 | usable | +4.09% | -5.17% | +3.54% | True |
| stealth-2 | usable | +0.00% | -0.63% | -1.17% | False |
