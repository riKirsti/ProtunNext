# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +0.38% | -0.48% | -9.55% | True |
| udp-1 | usable | -1.09% | +0.35% | -5.73% | True |
| udp-2 | usable | +0.00% | +1.20% | -13.79% | False |
| tcp-0 | usable | +0.01% | +0.23% | -0.51% | True |
| tcp-1 | usable | -0.22% | +0.16% | +0.11% | True |
| tcp-2 | usable | -0.00% | +1.43% | +7.07% | False |
| stealth-0 | usable | +4.80% | -8.27% | -1.55% | True |
| stealth-1 | usable | +14.53% | -10.82% | -2.42% | True |
| stealth-2 | usable | +0.00% | -9.49% | +3.80% | False |
