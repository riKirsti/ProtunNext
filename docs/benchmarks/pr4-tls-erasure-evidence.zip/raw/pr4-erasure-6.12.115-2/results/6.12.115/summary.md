# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +0.56% | -0.73% | -4.37% | True |
| udp-1 | usable | -2.83% | +1.08% | +1.92% | True |
| udp-2 | usable | +0.00% | +5.91% | +5.07% | False |
| tcp-0 | usable | -0.78% | +0.67% | -0.45% | True |
| tcp-1 | usable | +0.75% | -0.77% | +2.97% | True |
| tcp-2 | usable | +0.00% | -0.39% | +2.58% | False |
| stealth-0 | usable | +5.73% | -6.74% | -3.10% | True |
| stealth-1 | usable | +3.14% | -3.23% | +8.23% | True |
| stealth-2 | usable | +0.00% | -2.22% | -1.38% | False |
