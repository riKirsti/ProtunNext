# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | -0.47% | +0.23% | +8.94% | True |
| udp-1 | usable | -1.78% | +0.26% | -1.00% | True |
| udp-2 | usable | -0.00% | -0.32% | +3.73% | False |
| tcp-0 | usable | -0.80% | +1.40% | -6.80% | True |
| tcp-1 | usable | -0.80% | +1.25% | -1.53% | True |
| tcp-2 | usable | +0.00% | -3.81% | -1.54% | False |
| stealth-0 | usable | +5.24% | -9.43% | +8.70% | True |
| stealth-1 | inconclusive-control/load | +11.65% | -9.72% | -1.20% | False |
| stealth-2 | usable | +0.00% | -8.63% | +5.41% | False |
