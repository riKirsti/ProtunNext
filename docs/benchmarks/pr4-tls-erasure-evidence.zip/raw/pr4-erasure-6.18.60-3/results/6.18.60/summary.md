# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +1.91% | -2.11% | -0.88% | True |
| udp-1 | usable | +1.40% | -1.21% | -1.48% | True |
| udp-2 | usable | -0.00% | -0.94% | +1.61% | False |
| tcp-0 | usable | +0.15% | +0.41% | +1.58% | True |
| tcp-1 | usable | +0.42% | -0.27% | +6.01% | True |
| tcp-2 | usable | +0.00% | -3.20% | +5.54% | False |
| stealth-0 | usable | +2.56% | -7.09% | -3.65% | True |
| stealth-1 | usable | +5.82% | -5.87% | -2.46% | False |
| stealth-2 | usable | +0.00% | -3.82% | -4.84% | False |
