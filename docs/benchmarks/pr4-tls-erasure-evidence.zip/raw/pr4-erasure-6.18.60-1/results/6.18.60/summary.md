# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +1.07% | -0.14% | +0.01% | True |
| udp-1 | usable | +0.91% | -0.91% | +2.67% | True |
| udp-2 | usable | -0.00% | -3.12% | -4.06% | False |
| tcp-0 | usable | +0.79% | -0.03% | +6.87% | True |
| tcp-1 | usable | +0.29% | -0.28% | +2.40% | True |
| tcp-2 | usable | +0.00% | -0.21% | +5.18% | False |
| stealth-0 | usable | +2.86% | -5.90% | +2.30% | True |
| stealth-1 | usable | +4.08% | -4.14% | +1.03% | True |
| stealth-2 | usable | -0.00% | -3.56% | +2.30% | False |
