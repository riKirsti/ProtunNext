# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +0.21% | -0.24% | +4.01% | True |
| udp-1 | usable | -0.71% | +0.43% | -1.63% | True |
| udp-2 | usable | -0.00% | +1.34% | +0.73% | False |
| tcp-0 | usable | +0.75% | -0.26% | +3.15% | True |
| tcp-1 | usable | +0.22% | -0.22% | -10.42% | True |
| tcp-2 | usable | -0.00% | -3.13% | +0.00% | False |
| stealth-0 | usable | +1.90% | -4.19% | -4.39% | True |
| stealth-1 | usable | +6.32% | -5.87% | +0.24% | True |
| stealth-2 | usable | -0.00% | -2.89% | +2.01% | False |
