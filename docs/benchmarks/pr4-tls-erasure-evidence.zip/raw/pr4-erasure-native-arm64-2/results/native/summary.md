# Erasure comparison validity

Samples: 72/72; invalid-data errors: 0.

CPU/byte is client process cost; RSS is lifetime client peak and excludes kernel/peer/generator memory.
A/A tolerance is 5% for CPU/byte and throughput. Noisy cells are inconclusive; they are not retried until passing.

| Workload | Validity | Throughput delta | CPU/byte delta | Peak RSS delta | Capacity ranking |
|---|---|---:|---:|---:|---|
| udp-0 | usable | +0.87% | -1.20% | -1.09% | True |
| udp-1 | usable | -2.33% | +1.25% | -4.73% | True |
| udp-2 | usable | +0.00% | -1.95% | -3.20% | False |
| tcp-0 | usable | +0.21% | +1.31% | -6.76% | True |
| tcp-1 | usable | +2.25% | -1.56% | +0.32% | True |
| tcp-2 | usable | +0.00% | -1.48% | +11.79% | False |
| stealth-0 | usable | +5.37% | -8.55% | +1.61% | True |
| stealth-1 | usable | +11.79% | -10.21% | -4.62% | True |
| stealth-2 | usable | +0.00% | -12.15% | +2.56% | False |
