//! Optional Linux multishot receive. Sends remain sendmmsg-based; Mio observes
//! CQ notifications through eventfd alongside TUN, control and socket readiness.
//! No SQPOLL, busy polling, zero-copy-send loans or raw packet bypass.
use crate::{
    Error, Result,
    packet::{Packet, PacketPool},
    performance::IoCounters,
    stream::Receive,
};
use io_uring::{IoUring, cqueue, opcode, types};
use std::{
    fs::File,
    io,
    net::UdpSocket,
    os::fd::{AsRawFd, FromRawFd},
    ptr::NonNull,
    sync::atomic::{AtomicBool, AtomicU16, Ordering},
};
const GROUP: u16 = 7;
static SHUTDOWN_FAILED: AtomicBool = AtomicBool::new(false);
struct RingMemory {
    pointer: NonNull<types::BufRingEntry>,
    bytes: usize,
}
impl RingMemory {
    fn new(entries: usize) -> io::Result<Self> {
        // SAFETY: sysconf returns a scalar page size and does not access memory.
        let page = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
        if page <= 0 {
            return Err(io::Error::last_os_error());
        }
        let bytes =
            (entries * size_of::<types::BufRingEntry>()).div_ceil(page as usize) * page as usize;
        // SAFETY: a new private zero-filled, page-aligned mapping; no fixed address.
        let pointer = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                bytes,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            )
        };
        if pointer == libc::MAP_FAILED {
            return Err(io::Error::last_os_error());
        }
        Ok(Self {
            pointer: NonNull::new(pointer.cast()).expect("mmap address"),
            bytes,
        })
    }
}
impl Drop for RingMemory {
    fn drop(&mut self) {
        // SAFETY: exclusively owned mapping, released only after kernel buffer access stops.
        unsafe {
            libc::munmap(self.pointer.as_ptr().cast(), self.bytes);
        }
    }
}
pub(crate) struct Receiver {
    message: Box<libc::msghdr>,
    aggregate: Packet,
    segment: usize,
    offset: usize,
    ring: Option<IoUring>,
    memory: Option<RingMemory>,
    buffers: Vec<Packet>,
    event: File,
    tail: u16,
    active: bool,
    pub(crate) disabled: bool,
    pub(crate) submissions: u64,
}
impl Receiver {
    pub(crate) fn new(socket: &UdpSocket, count: u16) -> io::Result<Self> {
        if SHUTDOWN_FAILED.load(Ordering::Acquire) {
            return Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "io_uring disabled after cancellation failure",
            ));
        }
        let ring = IoUring::builder().setup_cqsize(128).build(32)?;
        // Require safe bounded shutdown support *before* submitting buffer loans.
        match ring.submitter().register_sync_cancel(
            Some(types::Timespec::new().sec(1)),
            types::CancelBuilder::any(),
        ) {
            Ok(()) => {}
            Err(e) if e.raw_os_error() == Some(libc::ENOENT) => {}
            Err(e) => return Err(e),
        }
        let mut probe = io_uring::Probe::new();
        ring.submitter().register_probe(&mut probe)?;
        if !probe.is_supported(opcode::RecvMsgMulti::CODE) {
            return Err(io::ErrorKind::Unsupported.into());
        }
        let count = std::env::var("BENCH_BUFFERS").ok().and_then(|s|s.parse::<u16>().ok()).unwrap_or(count).max(8).next_power_of_two() as usize;
        let memory = RingMemory::new(count)?;
        // SAFETY: allocates a new nonblocking notification descriptor, no borrowed memory.
        let event = unsafe { libc::eventfd(0, libc::EFD_NONBLOCK | libc::EFD_CLOEXEC) };
        if event < 0 {
            return Err(io::Error::last_os_error());
        }
        // SAFETY: successful eventfd returned a new uniquely owned descriptor.
        let event = unsafe { File::from_raw_fd(event) };
        let mut pool = PacketPool::new(count, 65535).map_err(io::Error::other)?;
        let buffers = (0..count)
            .map(|_| pool.take().expect("bounded count"))
            .collect();
        // SAFETY: page-aligned mapping and all buffers are owned until synchronous
        // cancellation/unregistration in Receiver::drop; ring length is a power of two.
        unsafe {
            ring.submitter().register_buf_ring_with_flags(
                memory.pointer.as_ptr() as u64,
                count as u16,
                GROUP,
                0,
            )?;
        }
        // From here every fallible setup step drops Receiver, which unregisters
        // the buffer group before allowing memory and payload buffers to drop.
        let mut message: Box<libc::msghdr> = Box::new(unsafe { std::mem::zeroed() });
        message.msg_controllen = 24;
        let mut extra = PacketPool::new(1,65535).map_err(io::Error::other)?;
        let mut receiver = Self { message, aggregate: extra.take().unwrap(), segment: 0, offset: 0,
            ring: Some(ring),
            memory: Some(memory),
            buffers,
            event,
            tail: 0,
            active: false,
            disabled: false,
            submissions: 0,
        };
        receiver
            .ring
            .as_ref()
            .expect("owned ring")
            .submitter()
            .register_eventfd(receiver.event.as_raw_fd())?;
        for id in 0..count {
            receiver.provide(id);
        }
        receiver.arm(socket)?;
        Ok(receiver)
    }
    pub(crate) fn event_fd(&self) -> i32 {
        self.event.as_raw_fd()
    }
    fn provide(&mut self, id: usize) {
        let memory = self.memory.as_ref().expect("registered mapping");
        let index = self.tail as usize & (self.buffers.len() - 1);
        let bytes = self.buffers[id].recvmsg_storage();
        // SAFETY: only the entry returned by the kernel is rewritten; the ring's
        // published tail is advanced with release ordering *after* these fields.
        unsafe {
            let entry = &mut *memory.pointer.as_ptr().add(index);
            entry.set_addr(bytes.as_mut_ptr() as u64);
            entry.set_len(bytes.len() as u32);
            entry.set_bid(id as u16);
        }
        self.tail = self.tail.wrapping_add(1);
        // SAFETY: tail is the ABI's aligned u16 shared producer field. This sole
        // worker publishes it atomically, after initializing the offered entry.
        unsafe {
            let tail = types::BufRingEntry::tail(memory.pointer.as_ptr()).cast::<AtomicU16>();
            (&*tail).store(self.tail, Ordering::Release);
        }
    }
    fn arm(&mut self, socket: &UdpSocket) -> io::Result<()> {
        if self.active || self.disabled {
            return Ok(());
        }
        let entry = opcode::RecvMsgMulti::new(types::Fd(socket.as_raw_fd()), &*self.message, GROUP)
            .flags(libc::MSG_TRUNC as _)
            .build()
            .user_data(1);
        let ring = self.ring.as_mut().expect("owned ring");
        // SAFETY: socket stays alive in Datagram, and all published buffers are
        // retained until final completion or synchronous cancellation in Drop.
        unsafe {
            ring.submission()
                .push(&entry)
                .map_err(|_| io::Error::other("receive SQ full"))?;
        }
        self.active = true;
        self.submissions += 1;
        ring.submit()?;
        Ok(())
    }
    fn drain_event(&self) {
        let mut value = 0u64;
        // SAFETY: nonblocking eventfd writes exactly one u64 into this live scalar.
        unsafe {
            libc::read(self.event.as_raw_fd(), (&mut value as *mut u64).cast(), 8);
        }
    }
    pub(crate) fn receive(
        &mut self,
        socket: &UdpSocket,
        output: &mut Packet,
        counters: &mut IoCounters,
    ) -> Result<Receive> {
        if output.writable().len() != 65535 {
            return Err(Error::Invalid("io_uring requires full receive slots"));
        }
        if self.segment > 0 {
            let end=(self.offset+self.segment).min(self.aggregate.data().len());
            let n=end-self.offset;
            output.writable()[..n].copy_from_slice(&self.aggregate.data()[self.offset..end]);
            output.set_len(n)?; self.offset=end;
            if end==self.aggregate.data().len() {self.segment=0;self.offset=0;}
            counters.received_datagrams+=1;
            return Ok(Receive::Packet);
        }
        self.arm(socket)?;
        let mut completion = self.ring.as_mut().expect("owned ring").completion().next();
        if completion.is_none() {
            self.drain_event();
            // Flush terminal CQEs retained in the kernel overflow list.
            // submit() observes CQ_OVERFLOW and uses GETEVENTS with min_complete=0.
            let ring = self.ring.as_mut().expect("owned ring");
            if ring.submission().cq_overflow() { ring.submit()?; }
            completion = ring.completion().next();
        }
        let Some(completion) = completion else {
            return Ok(Receive::WouldBlock);
        };
        self.active = cqueue::more(completion.flags());
        counters.io_uring_completions += 1;
        let result = completion.result();
        let id = cqueue::buffer_select(completion.flags()).map(usize::from);
        if let Some(id) = id {
            if id >= self.buffers.len() {
                return Err(Error::Invalid("io_uring buffer id"));
            }
            if result >= 0 && result as usize <= 65575 {
                let parsed=types::RecvMsgOut::parse(&self.buffers[id].recvmsg_storage()[..result as usize], &self.message).map_err(|_|Error::Invalid("recvmsg layout"))?;
                if parsed.is_payload_truncated() || parsed.is_control_data_truncated() {return Err(Error::Invalid("recvmsg truncated"));}
                let length=parsed.payload_data().len();
                let offset=16+self.message.msg_namelen as usize+self.message.msg_controllen as usize;
                let mut control: libc::msghdr=unsafe{std::mem::zeroed()};
                control.msg_control=parsed.control_data().as_ptr().cast_mut().cast();
                control.msg_controllen=parsed.control_data().len() as _;
                let segment=crate::linux_batch::gro_size(&control)?;
                self.buffers[id].set_len(length)?;
                std::mem::swap(output, &mut self.buffers[id]);
                self.buffers[id].set_len(0)?;self.provide(id);
                let _=offset; output.set_data_len(length)?;
                counters.received_bytes+=length as u64;
                if segment>0 {
                    counters.gro_datagrams+=length.div_ceil(segment) as u64;
                    std::mem::swap(output,&mut self.aggregate);self.segment=segment;self.offset=0;
                    return self.receive(socket,output,counters);
                }
                counters.received_datagrams+=1; return Ok(Receive::Packet);
            }
            self.buffers[id].set_len(0)?;
            self.provide(id);
        }
        if result == 0 {
            // A zero-length UDP message is a datagram, not TCP EOF. Some
            // kernels can complete it without selecting a payload buffer.
            output.set_len(0)?;
            counters.received_datagrams += 1;
            counters.max_receive_batch = counters.max_receive_batch.max(1);
            return Ok(Receive::Packet);
        }
        if result > 0 {
            counters.truncated_datagrams += 1;
            return Ok(Receive::Yield);
        }
        match -result {
            libc::ENOBUFS => {
                counters.enobufs += 1;
                Ok(Receive::Yield)
            }
            libc::EINTR | libc::EAGAIN => Ok(Receive::Yield),
            libc::EINVAL | libc::EOPNOTSUPP | libc::ENOSYS => {
                self.disabled = true;
                counters.kernel_fallbacks += 1;
                Err(Error::Unsupported("kernel multishot receive"))
            }
            code => Err(io::Error::from_raw_os_error(code).into()),
        }
    }
}
impl Drop for Receiver {
    fn drop(&mut self) {
        if let Some(ring) = self.ring.as_ref() {
            let stopped = match ring.submitter().register_sync_cancel(
                Some(types::Timespec::new().sec(1)),
                types::CancelBuilder::any(),
            ) {
                Ok(()) => true,
                Err(e) if e.raw_os_error() == Some(libc::ENOENT) => true,
                Err(_) => false,
            };
            if !stopped {
                SHUTDOWN_FAILED.store(true, Ordering::Release);
                log::warn!(
                    "io_uring cancellation failed; quarantining receive buffers and disabling new rings"
                );
                // A kernel refusing cancellation must never be allowed to access freed
                // userspace buffers. Quarantine these bounded allocations on this rare
                // shutdown failure; closing the ring releases its kernel resources.
                std::mem::forget(std::mem::take(&mut self.buffers));
                if let Some(memory) = self.memory.take() {
                    std::mem::forget(memory);
                }
            } else {
                let _ = ring.submitter().unregister_buf_ring(GROUP);
            }
        }
        // Destroy the ring before the registered mapping and buffers are released.
        self.ring.take();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn real_multishot_receive_recycles_buffers_and_cancels_an_idle_request() {
        let a = UdpSocket::bind("127.0.0.1:0").unwrap();
        let b = UdpSocket::bind("127.0.0.1:0").unwrap();
        a.connect(b.local_addr().unwrap()).unwrap();
        b.connect(a.local_addr().unwrap()).unwrap();
        b.set_nonblocking(true).unwrap();
        let mut receiver = match Receiver::new(&b, 8) {
            Ok(receiver) => receiver,
            Err(e) => {
                assert_ne!(
                    std::env::var("PROTUN_REQUIRE_URING").as_deref(),
                    Ok("1"),
                    "required io_uring unavailable: {e}"
                );
                eprintln!("io_uring unavailable; portable fallback is required: {e}");
                return;
            }
        };
        let mut pool = PacketPool::new(2, 65535).unwrap();
        let mut output = pool.take().unwrap();
        let mut counters = IoCounters::default();
        for turn in 0..16 {
            // More than the eight registered buffers, checking wrap/reuse.
            for n in 0..4 {
                let size = if n == 0 {
                    0
                } else if n == 1 {
                    1280
                } else {
                    4
                };
                a.send(&vec![turn ^ n; size]).unwrap();
            }
            for n in 0..4 {
                let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
                loop {
                    assert!(std::time::Instant::now() < deadline, "completion deadline");
                    match receiver.receive(&b, &mut output, &mut counters) {
                        Ok(Receive::Packet) => break,
                        Err(Error::Unsupported(_)) => {
                            assert_ne!(std::env::var("PROTUN_REQUIRE_URING").as_deref(), Ok("1"));
                            return;
                        }
                        Ok(_) => std::thread::sleep(std::time::Duration::from_millis(1)),
                        Err(e) => panic!("receive: {e}"),
                    }
                }
                let size = if n == 0 {
                    0
                } else if n == 1 {
                    1280
                } else {
                    4
                };
                assert_eq!(output.data(), vec![turn ^ n; size]);
            }
        }
        assert_eq!(counters.received_datagrams, 64);
        assert!(
            receiver.submissions < 64,
            "must use genuine multishot requests"
        );
        eprintln!(
            "actual multishot: {} datagrams, {} submissions",
            counters.received_datagrams, receiver.submissions
        );
        let start = std::time::Instant::now();
        drop(receiver);
        assert!(
            start.elapsed() < std::time::Duration::from_secs(2),
            "idle cancellation must be bounded"
        );
    }
}
#[cfg(test)]
mod decision_edges {
 use super::*;
 use crate::performance::Options;
 #[test]
 fn full_payload_capacity_gro_short_tail_ipv4_ipv6_and_shutdown(){
  for ipv6 in [false,true]{
   let bind=if ipv6{"[::1]:0"}else{"127.0.0.1:0"};let a=UdpSocket::bind(bind).unwrap();let b=UdpSocket::bind(bind).unwrap();a.connect(b.local_addr().unwrap()).unwrap();b.connect(a.local_addr().unwrap()).unwrap();b.set_nonblocking(true).unwrap();
   let mut o=Options::default();o.udp_offload=true;let _gro=crate::linux_batch::Batch::new(&b,o);
   let mut r=Receiver::new(&b,8).expect("required io_uring");let mut pool=PacketPool::new(2,65535).unwrap();let mut out=pool.take().unwrap();let mut c=IoCounters::default();
   for size in [0,1,1280,if ipv6{65480}else{65507}]{
    let body=vec![0x5a;size];a.send(&body).unwrap();let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);
    loop{assert!(std::time::Instant::now()<deadline);if matches!(r.receive(&b,&mut out,&mut c).unwrap(),Receive::Packet){break;}std::thread::yield_now();}assert_eq!(out.data(),body);
   }
   let segment:libc::c_int=1280;assert_eq!(unsafe{libc::setsockopt(a.as_raw_fd(),libc::SOL_UDP,libc::UDP_SEGMENT,(&segment as *const libc::c_int).cast(),4)},0);a.send(&vec![0x5a;1280*16+17]).unwrap();
   for i in 0..17 {let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);loop{assert!(std::time::Instant::now()<deadline);if matches!(r.receive(&b,&mut out,&mut c).unwrap(),Receive::Packet){break;}std::thread::yield_now();}assert_eq!(out.data().len(),if i==16{17}else{1280});assert!(out.data().iter().all(|x|*x==0x5a));}
   assert!(c.gro_datagrams>0);assert_eq!(c.kernel_fallbacks,0);assert_eq!(c.enobufs,0);let t=std::time::Instant::now();drop(r);assert!(t.elapsed()<std::time::Duration::from_secs(2));
  }
 }
}

#[cfg(test)]
mod overflow_regression {
 use super::*;
 #[test]
 fn full_completion_queue_releases_terminal_enobufs_and_resumes() {
  let a=UdpSocket::bind("127.0.0.1:0").unwrap();let b=UdpSocket::bind("127.0.0.1:0").unwrap();
  a.connect(b.local_addr().unwrap()).unwrap();b.connect(a.local_addr().unwrap()).unwrap();b.set_nonblocking(true).unwrap();
  let mut r=Receiver::new(&b,128).expect("required io_uring");
  for _ in 0..512 {a.send(&[0x33;16]).unwrap();}
  std::thread::sleep(std::time::Duration::from_millis(100));
  assert!(r.ring.as_mut().unwrap().submission().cq_overflow(),"must actually exercise CQ overflow");
  let mut p=PacketPool::new(2,65535).unwrap();let mut out=p.take().unwrap();let mut c=IoCounters::default();
  let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);
  loop {
   assert!(std::time::Instant::now()<deadline,"overflow recovery deadline: completions={}, enobufs={}, submissions={}",c.io_uring_completions,c.enobufs,r.submissions);
   let result=r.receive(&b,&mut out,&mut c).unwrap();
   if c.enobufs>0 && r.submissions>1 && matches!(result,Receive::WouldBlock) {break;}
   if matches!(result,Receive::WouldBlock){std::thread::sleep(std::time::Duration::from_millis(1));}
  }
  a.send(&[0x77;72]).unwrap();let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);
  loop {assert!(std::time::Instant::now()<deadline,"post-overflow receive deadline");if matches!(r.receive(&b,&mut out,&mut c).unwrap(),Receive::Packet) {assert_eq!(out.data(),[0x77;72]);break;}std::thread::yield_now();}
  assert_eq!(c.kernel_fallbacks,0);eprintln!("CQ overflow recovered: completions={}, enobufs={}, submissions={}",c.io_uring_completions,c.enobufs,r.submissions);
 }
}
