import hashlib,json,pathlib,re,shlex,sys
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
prior=json.loads(pathlib.Path('work/travel-decision-uring-diagnostic-20261105-private/evidence.json').read_text());assert all(prior['cleanup'].values())
with Lab('travel-decision-pgo-regressions-20261105-private',{'new':B/'nsrun','core':B/'core'},budget=300,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode());lab.report['tests']=[]
 for i,(name,path) in enumerate(json.loads(pathlib.Path('work/travel-test-pgo-executables.json').read_text())):
  data=pathlib.Path(path).read_bytes();filename='test'+chr(97+i);lab.put(filename,data,0o700)
  for ignored in ([False,True] if name=='linux_tun' else [False]):
   args=[lab.stage+'/core','--limit','90',lab.stage+'/new',lab.stage+'/'+filename,'--test-threads=1']+(['--ignored']if ignored else[])
   r=lab.run('PROTUN_REQUIRE_URING=1 PROTUN_NEXT_NETNS_TEST=1 '+' '.join(map(shlex.quote,args)),100)
   lab.report['tests'].append({'target':name,'ignored_run':ignored,'sha256':hashlib.sha256(data).hexdigest(),**r});lab.save();print(json.dumps({'regression':name,'ignored':ignored,'exit':r['code']}),flush=True)
  lab.check('rm -f '+lab.stage+'/'+filename)
