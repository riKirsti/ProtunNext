"""Separate GRO/backend factors after the main comparison and production bridge."""
import ast,json,pathlib,re,shlex,sys,time
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
deadline=time.monotonic()+1500
while True:
 try:done=json.loads(pathlib.Path('work/travel-decision-bridge-20261105-private/evidence.json').read_text())
 except (OSError,ValueError):done={}
 if done.get('cleanup'):break
 if time.monotonic()>deadline:raise RuntimeError('bridge not finished; do not overlap timings')
 time.sleep(2)
assert all(done['cleanup'].values())
original=json.loads(pathlib.Path('work/travel-decision-live-20261105-private/evidence.json').read_text());host=original['target']['host'];ip=original['target']['ip'];url=original['target']['url'];nodes=original['selected_nodes']
# Reuse the exact original download/connection helpers; do not execute its runner.
tree=ast.parse(pathlib.Path('work/travel-decision-followup.py').read_text())
for block in tree.body:
 if isinstance(block,ast.With):
  for f in block.body:
   if isinstance(f,ast.FunctionDef) and f.name in ['download','stats','start']:
    exec(compile(ast.Module(body=[f],type_ignores=[]),'<same live-test helpers>','exec'))
with Lab('travel-decision-uring-diagnostic-20261105-private',{'new':B/'live','launch':pathlib.Path('work/stealth-deep-private/launch.elf')},budget=450,sample_cap=25,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode())
 lab.report.update(target=original['target'],sessions=[],scope='additional balanced UDP io_uring GRO isolation; same server/config/origin, no code fix')
 modes=[('batch-offload','batch,offload,compact,in-place'),('uring-no-offload','uring,compact,in-place'),('uring-offload','uring,offload,compact,in-place')]
 for round_id in range(2):
  for node in (nodes if round_id==0 else nodes[::-1]):
   for label,flags in (modes if round_id==0 else modes[::-1]):
    assert time.monotonic()+45<lab.deadline
    row={'server':node['name'],'variant':label,'round':round_id,'protocol':'udp','flags':flags,'samples':[]};lab.report['sessions'].append(row);lab.save()
    row['connected']=start(node,'udp',flags)
    if row['connected']:
     row['cold']=download(lab.ifname,500000,8);time.sleep(4);before=stats();sample=download(lab.ifname,50000000);after=stats();sample.update(before=before,after=after);row['samples'].append(sample)
    row['diagnostics']=lab.read(lab.stage+'/phase.log');lab.save();print(json.dumps({'diagnostic_server':node['name'],'variant':label,'round':round_id,'connected':row['connected'],'valid':row['samples'][0]['valid']if row['samples']else False}),flush=True);lab.stop()
