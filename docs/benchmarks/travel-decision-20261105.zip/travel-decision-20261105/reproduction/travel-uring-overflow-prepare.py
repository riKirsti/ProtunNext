import hashlib,pathlib
p=pathlib.Path('work/ProtunNext/reference/src/uring_rx.rs')
out=pathlib.Path('work/travel-decision-binaries')
text=p.read_text();(out/'uring-before.rs').write_text(text)
test=r'''
#[cfg(test)]
mod overflow_regression {
 use super::*;
 #[test]
 fn full_completion_queue_releases_terminal_enobufs_and_resumes() {
  let a=UdpSocket::bind("127.0.0.1:0").unwrap();let b=UdpSocket::bind("127.0.0.1:0").unwrap();
  a.connect(b.local_addr().unwrap()).unwrap();b.connect(a.local_addr().unwrap()).unwrap();b.set_nonblocking(true).unwrap();
  let mut r=Receiver::new(&b,128).expect("required io_uring");
  for _ in 0..512 {a.send(&[0x33;16]).unwrap();}
  std::thread::sleep(std::time::Duration::from_millis(100));
  assert!(r.ring.as_mut().unwrap().submission().cq_overflow(),"must actually exercise CQ overflow");
  let mut p=PacketPool::new(2,65535).unwrap();let mut out=p.take().unwrap();let mut c=IoCounters::default();
  let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);
  loop {
   assert!(std::time::Instant::now()<deadline,"overflow recovery deadline: completions={}, enobufs={}, submissions={}",c.io_uring_completions,c.enobufs,r.submissions);
   let result=r.receive(&b,&mut out,&mut c).unwrap();
   if c.enobufs>0 && r.submissions>1 && matches!(result,Receive::WouldBlock) {break;}
   if matches!(result,Receive::WouldBlock){std::thread::sleep(std::time::Duration::from_millis(1));}
  }
  a.send(&[0x77;72]).unwrap();let deadline=std::time::Instant::now()+std::time::Duration::from_secs(2);
  loop {assert!(std::time::Instant::now()<deadline,"post-overflow receive deadline");if matches!(r.receive(&b,&mut out,&mut c).unwrap(),Receive::Packet) {assert_eq!(out.data(),[0x77;72]);break;}std::thread::yield_now();}
  assert_eq!(c.kernel_fallbacks,0);eprintln!("CQ overflow recovered: completions={}, enobufs={}, submissions={}",c.io_uring_completions,c.enobufs,r.submissions);
 }
}
'''
p.write_text(text+test)
(out/'overflow-regression.rs').write_text(test)
print(hashlib.sha256(text.encode()).hexdigest())
