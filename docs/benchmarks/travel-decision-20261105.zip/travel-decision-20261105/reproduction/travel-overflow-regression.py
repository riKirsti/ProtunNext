import json,pathlib,re,shlex,sys
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
assert all(json.loads(pathlib.Path('work/travel-decision-pgo-regressions-20261105-private/evidence.json').read_text())['cleanup'].values())
with Lab('travel-decision-overflow-regression-20261105-private',{'new':B/'nsrun','core':B/'core','before':B/'overflowbefore','after':B/'overflowafter'},budget=100,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode());lab.report['tests']=[]
 for binary in ['before','after']:
  r=lab.run('BENCH_BUFFERS=128 PROTUN_REQUIRE_URING=1 '+' '.join(map(shlex.quote,[lab.stage+'/core','--limit','15',lab.stage+'/new',lab.stage+'/'+binary,'overflow_regression','--nocapture','--test-threads=1'])),20)
  lab.report['tests'].append({'build':binary,**r});lab.save();print(json.dumps({'build':binary,**r}),flush=True)
 r=lab.run('BENCH_BUFFERS=128 PROTUN_REQUIRE_URING=1 '+' '.join(map(shlex.quote,[lab.stage+'/core','--limit','30',lab.stage+'/new',lab.stage+'/after','uring_rx::','--nocapture','--test-threads=1'])),35)
 lab.report['tests'].append({'build':'after-all-uring',**r});lab.save();print(json.dumps({'build':'after-all-uring',**r}),flush=True)
