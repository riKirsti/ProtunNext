"""Build-only preparation; does not connect to or change any router."""
from pathlib import Path
import runpy

root = Path(__file__).resolve().parents[2]
runpy.run_path(str(root / 'experiments/decision/prepare.py'))
for binary, module in [('decision', 'decision'), ('decision-worker', 'decision_worker')]:
    # Namespace creation happens before the benchmark creates any threads or TUNs.
    # A failed namespace probe exits without changing the router's host network.
    main = '''fn main() {
 let args:Vec<_>=std::env::args().collect();
 if args.get(1).map(String::as_str)==Some("--limit") {
  let seconds:f64=args[2].parse().unwrap();
  let mut child=std::process::Command::new(&args[3]).args(&args[4..]).spawn().unwrap();
  let until=std::time::Instant::now()+std::time::Duration::from_secs_f64(seconds);
  loop {if let Some(s)=child.try_wait().unwrap(){std::process::exit(s.code().unwrap_or(1));}
   if std::time::Instant::now()>=until {let _=child.kill();let _=child.wait();eprintln!("CASE_TIMEOUT {seconds}");std::process::exit(124);}
   std::thread::sleep(std::time::Duration::from_millis(20));
  }
 }
 let probe=std::env::args().nth(1).as_deref()==Some("--namespace-probe");
 if probe || std::env::var("PN_TEST_NETNS").as_deref()==Ok("1") {
  if unsafe { libc::unshare(libc::CLONE_NEWNET) } != 0 {
   eprintln!("NETNS_UNAVAILABLE: {}",std::io::Error::last_os_error());
   std::process::exit(77);
  }
  if probe { println!("NETNS_PROBE_OK"); return; }
  assert!(std::process::Command::new("ip").args(["link","set","lo","up"]).status().unwrap().success());
 }
 protun_next::MODULE::run();
}
'''.replace('MODULE', module)
    (root / 'reference/src/bin' / f'{binary}.rs').write_text(main)
