import json,pathlib,re,shlex,sys,time
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
p=pathlib.Path('work/travel-decision-live-20261105-private/evidence.json')
deadline=time.monotonic()+2700
while True:
 try:j=json.loads(p.read_text())
 except (OSError,ValueError):j={}
 if j.get('cleanup'):break
 if time.monotonic()>deadline:raise RuntimeError('live cleanup not observed; do not overlap bridge timings')
 time.sleep(2)
assert all(j['cleanup'].values())
with Lab('travel-decision-bridge-20261105-private',{'new':B/'worker','core':B/'core','production':B/'production','nsrun':B/'nsrun'},budget=300,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode());lab.report['samples']=[]
 for round_id in range(12):
  for proto in ['udp','tcp','stealth']:
   variant='batch-unbuffered-compact-inplace'if proto=='stealth'else 'batch-offload-compact-inplace'if proto=='udp'else 'batch-compact-inplace'
   for binary in (['new','production']if round_id%2==0 else ['production','new']):
    args=[lab.stage+'/core','--limit','15',lab.stage+'/nsrun',lab.stage+'/'+binary,proto,variant,'1200',str(round_id),'1.5','32','0','0']
    r=lab.run(' '.join(map(shlex.quote,args)),22);rows=[]
    for line in r['stdout'].splitlines():
     if 'HOUR_JSON 'in line:rows.append(json.loads(line.split('HOUR_JSON ',1)[1]))
    lab.report['samples'].append({'build':binary,'protocol':proto,'round':round_id,'rows':rows,**r});lab.save()
  print(json.dumps({'bridge_round_finished':round_id}),flush=True)
