import ast,json,pathlib,re,shlex,sys,time
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
prior=json.loads(pathlib.Path('work/travel-decision-uring-fixed-live-20261105-private/evidence.json').read_text());assert all(prior['cleanup'].values())
original=json.loads(pathlib.Path('work/travel-decision-live-20261105-private/evidence.json').read_text());host=original['target']['host'];ip=original['target']['ip'];url=original['target']['url'];nodes=original['selected_nodes']
tree=ast.parse(pathlib.Path('work/travel-decision-followup.py').read_text())
for block in tree.body:
 if isinstance(block,ast.With):
  for f in block.body:
   if isinstance(f,ast.FunctionDef)and f.name in ['download','kernel_start']:exec(compile(ast.Module(body=[f],type_ignores=[]),'<same live-test helpers>','exec'))
with Lab('travel-decision-kernel-readiness-20261105-private',{'new':B/'nsrun'},budget=160,sample_cap=25,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode());lab.report.update(sessions=[],scope='kernel-only followup: quiet time and explicit readiness, not mixed-protocol paired timing',target=original['target'])
 for node in nodes:
  row={'server':node['name'],'variant':'kernel','protocol':'udp','samples':[],'readiness_attempts':[]};lab.report['sessions'].append(row);lab.save();time.sleep(10);kernel_start(node)
  for n in range(4):
   sample=download(lab.kifname,500000,6);stamp=int(lab.check('wg show '+lab.kifname+' latest-handshakes').split()[-1]);row['readiness_attempts'].append({'attempt':n,'handshake_timestamp':stamp,**sample});lab.save()
   if sample['valid']and stamp:break
   time.sleep(3)
  row['samples'].append(download(lab.kifname,50000000));lab.save();print(json.dumps({'kernel_readiness_server':node['name'],'attempts':len(row['readiness_attempts']),'samples':row['samples']}),flush=True);lab.stop()
