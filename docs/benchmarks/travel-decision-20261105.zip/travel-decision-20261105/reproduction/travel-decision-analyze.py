import pathlib,json,statistics,collections,time,sys
OUT=pathlib.Path('outputs/travel-decision-20261105');OUT.mkdir(exist_ok=True)
def read(path):
 for _ in range(20):
  try:return json.loads(pathlib.Path(path).read_text())
  except FileNotFoundError:return None
  except ValueError:time.sleep(.05)
 raise RuntimeError('evidence file remained incomplete')
controlled=read('work/travel-decision-controlled-20261105-private/evidence.json')
live=read('work/travel-decision-live-20261105-private/evidence.json')
regress=read('work/travel-decision-regressions-20261105-private/evidence.json')
rows=[]
for n,c in enumerate(controlled['cases']):
 parsed=[]
 for line in c.get('stdout','').splitlines():
  p=line.split('HOUR_JSON ',1)[-1].split('DECISION_JSON ',1)[-1].strip()
  if p.startswith('{'):
   try:parsed.append(json.loads(p))
   except ValueError:pass
 if not parsed:parsed=c.get('rows',[])
 for r in parsed:
  if r.get('test')=='environment':continue
  r=dict(r);r.update(case_label=c['label'],case_index=n,case_exit=c['code']);rows.append(r)

labels={'worker','memory','latency','oversized','batch-limit','tls12','tun-aggregation'}
w=[r for r in rows if r['case_label']in labels and r.get('test')=='full-worker-controlled-peer']
index={(r['transport'],r['variant'],r['payload'],r['round'],r['window'],r['vnet']):r for r in w}
pairs=[]
def pair(r,b,label,family='worker'):
 if b is None:return
 item={'family':family,'comparison':label,'transport':r.get('transport'),'payload':r.get('payload',r.get('size',r.get('chunk'))),'round':r['round'],'window':r.get('window'),'speed_pct':100*(r['Mbps']/b['Mbps']-1),'candidate_Mbps':r['Mbps'],'baseline_Mbps':b['Mbps']}
 for field,name in [('worker_cpu_ns_per_byte','worker_cpu_pct'),('whole_process_cpu_ns_per_byte','whole_cpu_pct'),('process_peak_rss_kib','rss_pct'),('latency_p99_us','p99_pct')]:
  if r.get(field) is not None and b.get(field) and r[field]>0:item[name]=100*(r[field]/b[field]-1)
 pairs.append(item)
comparisons=[('batch-full-copy','portable-full-copy','mmsg-only'),('batch-compact-inplace','batch-compact-copy','inplace-compact'),('batch-full-inplace','batch-full-copy','inplace-full'),('batch-compact-copy','batch-full-copy','compact-copy'),('batch-compact-inplace','batch-full-inplace','compact-inplace'),('batch-offload-compact-inplace','batch-compact-inplace','outer-offloads'),('uring-compact-inplace','batch-compact-inplace','uring-no-offload'),('uring-offload-compact-inplace','batch-offload-compact-inplace','uring-offload'),('batch-unbuffered-compact-inplace','batch-buffered-compact-inplace','unbuffered-TLS13'),('batch-unbuffered-compact-inplace-tls12','batch-buffered-compact-inplace-tls12','unbuffered-TLS12'),('batch-buffered-compact-inplace','batch-buffered-compact-copy','inplace-buffered'),('batch-buffered-full-inplace','batch-buffered-full-copy','inplace-full-buffered'),('batch-buffered-compact-copy','batch-buffered-full-copy','compact-buffered'),('batch-buffered-compact-inplace','batch-buffered-full-inplace','compact-inplace-buffered'),('batch-buffered-full-inplace','batch-full-copy','inplace-full'),('batch-buffered-compact-copy','batch-full-copy','compact-copy'),('batch-compact-inplace','batch-buffered-compact-copy','inplace-compact'),('batch-compact-inplace','batch-buffered-full-inplace','compact-inplace')]
for a,b,label in comparisons:
 for r in w:
  if r['variant']==a and not r['vnet']:pair(r,index.get((r['transport'],b,r['payload'],r['round'],r['window'],False)),label)
for r in w:
 if r['vnet']:pair(r,index.get((r['transport'],r['variant'],r['payload'],r['round'],r['window'],False)),'TUN-aggregation-screening')
 if r['variant'].startswith('batch-limit'):pair(r,index.get((r['transport'],'batch-limit16-compact-inplace',r['payload'],r['round'],r['window'],False)),r['variant'].split('-')[1]+'-vs-16')

p=[r for r in rows if r.get('test')=='shared-session-crypto'];idx={(r['size'],r['round'],r['workers']):r for r in p}
for r in p:
 if r['workers']>1:pair(r,idx.get((r['size'],r['round'],1)),str(r['workers'])+'-workers','shared-session-primitive')
p=[r for r in rows if r['case_label'].startswith('pgo-')];idx={(r['transport'],r['payload'],r['round'],r['case_label']):r for r in p}
for r in p:
 if r['case_label']=='pgo-pgo':pair(r,idx.get((r['transport'],r['payload'],r['round'],'pgo-new')),'Travel-trained-PGO','whole-fixture-PGO')
tls=[r for r in rows if r['case_label']=='tls-component'];idx={(r['tls'],r['chunk'],r['direction'],r['round'],r['mode']):r for r in tls}
for r in tls:
 if r['mode']=='unbuffered':pair(r,idx.get((r['tls'],r['chunk'],r['direction'],r['round'],'buffered')),r['direction']+':'+r['tls'],'TLS-component')

g=collections.defaultdict(list)
for r in pairs:g[tuple((k,r.get(k))for k in ['family','comparison','transport','payload','window'])].append(r)
stats=[]
for k,v in g.items():
 s=dict(k);s['pairs']=len(v)
 for field in ['speed_pct','worker_cpu_pct','whole_cpu_pct','rss_pct','p99_pct']:
  x=[r[field]for r in v if field in r]
  s[field]={'median':statistics.median(x),'min':min(x),'max':max(x),'positive':sum(a>0 for a in x)}if x else None
 stats.append(s)

live_groups=collections.defaultdict(list)
if live:
 for s in live.get('sessions',[]):
  for r in s['samples']:live_groups[(s['server'],s['variant'],r['requested_bytes'])].append(r)
live_stats=[]
for (server,variant,size),a in live_groups.items():
 valid=[r for r in a if r['valid']]
 live_stats.append({'server':server,'variant':variant,'bytes':size,'attempts':len(a),'successes':len(valid),'median_Mbps':statistics.median(r['Mbps']for r in valid)if valid else None,'failures':[{'exit':r['exit'],'http_code':r['http_code'],'bytes':r['bytes'],'error':r['error']}for r in a if not r['valid']]})

soaks=[r for r in rows if r['case_label']=='concurrent-ten-minute-soak']
cold=[r for r in rows if r['case_label']=='cold-starts']
meta={'kernel':'6.12.112','architecture':'aarch64','cores':2,'one_physical_router':True,'main_bulk_pairs_balanced':True,'supplementary_cases_ordered':True,'scope':'isolated synthetic peer; UDP application echo. Whole-test RSS includes peer/generator; TUN raw/aggregate screening has unequal duration and generator sends. Concurrent soaks are stability tests, not fair throughput comparisons.'}
out={'metadata':meta,'counts':dict(collections.Counter(r['case_label']for r in rows)),'statistics':stats,'pairs':pairs,'rows':rows,'failures':controlled['failures'],'cold_starts':{'count':len(cold),'by_variant':dict(collections.Counter(r['variant']for r in cold))},'soaks':soaks,'cleanup_controlled':controlled.get('cleanup'),'regressions':regress,'live_summary':live_stats,'live':live}
(OUT/'analysis.json').write_text(json.dumps(out,indent=2))
lines=['Travel results: paired medians on one router. Twelve bulk pairs are balanced; extra cases have fixed order. Positive CPU/RSS/latency change means higher cost. Percentages are not additive.','','| Family | Comparison | Protocol | Payload / window | Pairs | Throughput | Worker CPU/B | Whole-test peak RSS | p99 |','|---|---|---|---:|---:|---:|---:|---:|---:|']
fmt=lambda r,k:'—'if r[k]is None else f'{r[k]["median"]:+.2f}%'
for r in sorted(stats,key=lambda x:(x['family'],x['transport']or'',x['payload']or 0,x['comparison'])):lines.append(f'| {r["family"]} | {r["comparison"]} | {r["transport"]or"—"} | {r["payload"]} / {r["window"]or"—"} | {r["pairs"]} | {fmt(r,"speed_pct")} | {fmt(r,"worker_cpu_pct")} | {fmt(r,"rss_pct")} | {fmt(r,"p99_pct")} |')
(OUT/'PAIRED-RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'counts':out['counts'],'failures':len(out['failures']),'cold':out['cold_starts'],'soaks':len(soaks),'live_sessions':len(live.get('sessions',[]))if live else 0,'cleanup':out['cleanup_controlled']},indent=2))
