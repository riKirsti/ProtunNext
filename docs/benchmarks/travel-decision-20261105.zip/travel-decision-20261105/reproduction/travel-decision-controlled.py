"""Temporary Travel hardware comparison; every networked case gets a private netns."""
import datetime,hashlib,json,re,shlex,sys,time
from pathlib import Path
sys.path.insert(0,'work')
from stealth_router_lab import Lab,utc
BIN=Path('work/travel-decision-binaries')
OUT=Path('work/travel-decision-controlled-20261105-private')
OUT.mkdir(exist_ok=True)
assert not (OUT/'evidence.json').exists(),'preserve previous evidence'
cases=[('udp','portable-full-copy'),('udp','portable-compact-inplace'),('udp','batch-full-copy'),('udp','batch-compact-copy'),('udp','batch-full-inplace'),('udp','batch-compact-inplace'),('udp','batch-offload-compact-inplace'),('udp','uring-compact-inplace'),('udp','uring-offload-compact-inplace'),('tcp','batch-full-copy'),('tcp','batch-compact-inplace'),('stealth','batch-buffered-full-copy'),('stealth','batch-buffered-compact-inplace'),('stealth','batch-unbuffered-compact-inplace')]
def rows(text):
 result=[]
 for line in text.splitlines():
  for prefix in ['HOUR_JSON ','DECISION_JSON ']:
   if prefix in line:
    try:result.append(json.loads(line.split(prefix,1)[1]))
    except ValueError:pass
 return result

with Lab(OUT.name,{'new':BIN/'worker','core':BIN/'core'},budget=2100,expected_mode='direct') as lab:
 clean=lab.read(lab.stage+'/cleanup.sh')
 clean=re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',clean,flags=re.M)
 lab.put('cleanup.sh',clean.encode())
 lab.report.update(scope='real Travel hardware, isolated network namespace per case; synthetic authenticated peer, no Proton account/configuration changes',cases=[],failures=[],source_reference='83f025231535a3ef0731123988e9dae8621cef4a',experiment_reference='78954944b81ed8c2372fc125b2a5f4327fb411a3',comparison_design='12 balanced paired rounds on ONE two-core router; not 12 independent machines',hardware=lab.check('uname -a; cat /proc/cpuinfo; cat /proc/sys/kernel/io_uring_disabled; cat /sys/class/thermal/thermal_zone0/temp; cat /proc/meminfo'))
 lab.report['namespace_probe']=lab.run(lab.stage+'/new --namespace-probe',10)
 assert lab.report['namespace_probe']['code']==0,'isolated namespace required'
 lab.save()
 def run(label,args,cap=18,namespace=True,binary='new'):
  assert time.monotonic()+cap+20<lab.deadline,'bounded test window reached'
  command=('PN_TEST_NETNS=1 ' if namespace else '')+' '.join(map(shlex.quote,[lab.stage+'/core','--limit',str(cap),lab.stage+'/'+binary]+list(map(str,args))))
  before=lab.check('cat /sys/class/thermal/thermal_zone0/temp; cat /proc/loadavg').strip()
  start=time.monotonic();r=lab.run(command,cap+8)
  item={'label':label,'args':args,'code':r['code'],'stdout':r['stdout'],'stderr':r['stderr'],'wall_seconds':time.monotonic()-start,'temperature_load_before':before,'rows':rows(r['stdout'])}
  lab.report['cases'].append(item)
  if r['code']:lab.report['failures'].append({'label':label,'args':args,'exit':r['code'],'error':r['stderr'][-500:]})
  lab.save();return item

 for proto,variant in [('udp','uring-offload-compact-inplace'),('tcp','batch-compact-inplace'),('stealth','batch-buffered-compact-inplace'),('stealth','batch-unbuffered-compact-inplace')]:
  r=run('pilot',[proto,variant,1200,99,1,32,0,0]);print(json.dumps({'pilot':proto,'variant':variant,'exit':r['code']}),flush=True)
  assert r['code']==0,'pilot failed; do not collect a broken matrix'

 for round_id in range(12):
  for proto,variant in (cases if round_id%2==0 else cases[::-1]):run('worker',[proto,variant,1200,round_id,1.5,32,0,0])
  for variant in ['batch-buffered-compact-inplace','batch-unbuffered-compact-inplace']:
   run('latency',['stealth',variant,64,round_id,1,1,1,0])
   run('oversized',['stealth',variant,2048,round_id,1,16,0,0])
  for limit in [1,8,16,32]:run('batch-limit',['udp',f'batch-limit{limit}-compact-inplace',1200,round_id,1,32,0,0])
  for proto in ['tcp','stealth']:
   for variant in ['batch-buffered-compact-copy','batch-buffered-full-inplace']:run('memory',[proto,variant,1200,round_id,1,32,0,0])
  for variant in ['portable-compact-inplace','batch-compact-inplace','uring-offload-compact-inplace']:run('latency',['udp',variant,64,round_id,1,1,1,0])
  for variant in ['batch-buffered-compact-inplace-tls12','batch-unbuffered-compact-inplace-tls12']:run('tls12',['stealth',variant,1200,round_id,1,32,0,0])
  for proto,variant in [('udp','batch-offload-compact-inplace'),('stealth','batch-unbuffered-compact-inplace')]:run('tun-aggregation',[proto,variant,1200,round_id,1,32,0,1])
  print(json.dumps({'worker_round_finished':round_id,'failures':len(lab.report['failures']),'elapsed_seconds':round(time.monotonic()-lab.start,1)}),flush=True)

 for args,label,cap in [(['--cpu'],'crypto-pool',120),(['--parallel'],'shared-session-parallel',180),(['--tun'],'tun-boundary',120)]:
  r=run(label,args,cap=cap,binary='core');print(json.dumps({'component':label,'exit':r['code']}),flush=True)
 socket_cases=[('single',0,0,16),('batch',0,0,16),('batch',1,0,16),('batch',0,1,16),('batch',1,1,16),('uring16',0,0,16),('uring128',0,0,128),('uring128',1,0,128),('uring128',0,1,128),('uring128',1,1,128)]
 for round_id in range(4):
  for size in [64,1280]:
   for mode,gso,gro,buffers in (socket_cases if round_id%2==0 else socket_cases[::-1]):run('udp-component',['--udp',mode,size,round_id,gso,gro,buffers],cap=40,binary='core')
  print(json.dumps({'socket_round_finished':round_id,'failures':len(lab.report['failures'])}),flush=True)

 tls=BIN/'tls'
 if tls.exists():
  lab.put('tls',tls.read_bytes(),0o700);lab.report['binary_sha256']['tls']=hashlib.sha256(tls.read_bytes()).hexdigest()
  for args in [['67108864'],['--framed']]:
   r=run('tls-component',args,cap=180,binary='tls');print(json.dumps({'component':'tls','args':args,'exit':r['code']}),flush=True)

 # Three hundred new process/connection starts per adapter, preserving every attempt.
 for variant in ['batch-buffered-compact-inplace','batch-unbuffered-compact-inplace']:
  for start in range(0,300,25):
   command='n='+str(start)+'; while [ "$n" -lt '+str(start+25)+' ]; do PN_TEST_NETNS=1 '+lab.stage+'/core --limit 12 '+lab.stage+'/new stealth '+variant+' 64 "$n" 0 1 0 0 || exit $?; n=$((n+1)); done'
   r=lab.run(command,90);item={'label':'cold-starts','variant':variant,'start':start,'code':r['code'],'stdout':r['stdout'],'stderr':r['stderr'],'rows':rows(r['stdout'])};lab.report['cases'].append(item)
   if r['code']:lab.report['failures'].append({'label':'cold-starts','variant':variant,'start':start,'exit':r['code']})
   lab.save()
  print(json.dumps({'cold_finished':variant}),flush=True)

 # Train on this router, not on a different ARM CPU. Build/merge stays on the laptop.
 gen=BIN/'gen'
 if gen.exists():
  lab.put('gen',gen.read_bytes(),0o700);lab.report['binary_sha256']['gen']=hashlib.sha256(gen.read_bytes()).hexdigest()
  for proto in ['udp','tcp','stealth']:
   variant='batch-unbuffered-compact-inplace' if proto=='stealth' else 'batch-offload-compact-inplace'
   for size in [256,1000]:
    cmd='LLVM_PROFILE_FILE='+shlex.quote(lab.stage+'/profile-%m-%p.profraw')+' PN_TEST_NETNS=1 '+lab.stage+'/core --limit 18 '+lab.stage+'/gen '+proto+' '+variant+' '+str(size)+' 99 0.5 32 0 0'
    r=lab.run(cmd,25);assert r['code']==0,'PGO training failed';lab.report['cases'].append({'label':'pgo-training','code':r['code'],'rows':rows(r['stdout'])});lab.save()
  profiles=lab.check('ls '+lab.stage+'/*.profraw').splitlines();local=OUT/'profiles';local.mkdir(exist_ok=True)
  for f in profiles:
   assert re.fullmatch(re.escape(lab.stage)+r'/profile-[A-Za-z0-9_.-]+\.profraw',f)
   _,o,e=lab.c.exec_command('cat '+shlex.quote(f),timeout=30);data=o.read();assert o.channel.recv_exit_status()==0;(local/Path(f).name).write_bytes(data)
  (OUT/'training-ready.json').write_text(json.dumps({'stage':lab.stage,'profiles':len(profiles),'router_training':True}))
  print(json.dumps({'pgo_profiles_ready':len(profiles)}),flush=True)

 # Concurrent soaks are a correctness/stability stress, not protocol throughput comparisons.
 channels=[]
 for proto in ['udp','tcp','stealth']:
  variant='batch-unbuffered-compact-inplace' if proto=='stealth' else 'batch-offload-compact-inplace' if proto=='udp' else 'batch-compact-inplace'
  command='PN_TEST_NETNS=1 '+lab.stage+'/core --limit 630 '+lab.stage+'/new '+proto+' '+variant+' 1200 0 600 32 0 0'
  _,out,err=lab.c.exec_command(command,timeout=650);channels.append((proto,out,err))
  print(json.dumps({'soak_started':proto}),flush=True)
 last=time.monotonic()
 while not all(o.channel.exit_status_ready() for _,o,_ in channels):
  assert time.monotonic()+20<lab.deadline
  if time.monotonic()-last>40:print(json.dumps({'soak_running_seconds':round(time.monotonic()-last_soak,1)}) if 'last_soak' in locals() else {'soak_running':True},flush=True);last=time.monotonic()
  time.sleep(1)
 for proto,o,e in channels:
  text=o.read().decode();error=e.read().decode();code=o.channel.recv_exit_status();item={'label':'concurrent-ten-minute-soak','transport':proto,'code':code,'rows':rows(text),'stderr':error};lab.report['cases'].append(item)
  if code:lab.report['failures'].append({'label':'soak','transport':proto,'exit':code,'error':error[-500:]})
  print(json.dumps({'soak_finished':proto,'exit':code}),flush=True);lab.save()

 pgo=BIN/'pgo'
 if pgo.exists() and (OUT/'training-ready.json').exists():
  lab.put('pgo',pgo.read_bytes(),0o700);lab.report['binary_sha256']['pgo']=hashlib.sha256(pgo.read_bytes()).hexdigest()
  for round_id in range(4):
   for proto in ['udp','tcp','stealth']:
    variant='batch-unbuffered-compact-inplace' if proto=='stealth' else 'batch-offload-compact-inplace'
    for size in [64,1200]:
     for build in (['new','pgo'] if round_id%2==0 else ['pgo','new']):run('pgo-'+build,[proto,variant,size,round_id,1.5,32,0,0],binary=build)
  print(json.dumps({'pgo_comparison_finished':True}),flush=True)
 else:lab.report['pgo_status']='profile-used binary unavailable; not counted as passed'
 lab.report['extra_configuration_unchanged']=lab.check('uci -q get exitnode.main.mode').strip()=='direct';lab.save()
