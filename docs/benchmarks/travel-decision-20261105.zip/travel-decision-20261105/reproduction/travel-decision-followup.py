"""Wait for isolated timing to finish, then run isolated regressions and live controls."""
import datetime,hashlib,json,re,shlex,socket,sys,time
from pathlib import Path
sys.path.insert(0,'work')
from stealth_router_lab import Lab,utc
BIN=Path('work/travel-decision-binaries')
evidence=Path('work/travel-decision-controlled-20261105-private/evidence.json')
until=time.monotonic()+2200;last=0
while True:
 try:prior=json.loads(evidence.read_text())
 except (ValueError,OSError):prior={}
 if prior.get('cleanup'):break
 if time.monotonic()>until:raise RuntimeError('controlled test cleanup not observed; do not overlap measurements')
 if time.monotonic()-last>40:print(json.dumps({'waiting_for_controlled_cleanup':True}),flush=True);last=time.monotonic()
 time.sleep(2)
assert all(prior['cleanup'].values()),'prior cleanup needs investigation before new tests'

with Lab('travel-decision-regressions-20261105-private',{'new':BIN/'nsrun','core':BIN/'core'},budget=300,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode())
 lab.report['tests']=[]
 exes=json.loads(Path('work/travel-test-executables.json').read_text())
 for i,(name,path) in enumerate(exes):
  data=Path(path).read_bytes();filename='test'+chr(97+i);lab.put(filename,data,0o700)
  for ignored in ([False,True] if name=='linux_tun' else [False]):
   args=[lab.stage+'/core','--limit','90',lab.stage+'/new',lab.stage+'/'+filename,'--test-threads=1']+(['--ignored']if ignored else[])
   r=lab.run('PROTUN_REQUIRE_URING=1 PROTUN_NEXT_NETNS_TEST=1 '+' '.join(map(shlex.quote,args)),100)
   row={'target':name,'ignored_run':ignored,'sha256':hashlib.sha256(data).hexdigest(),**r};lab.report['tests'].append(row);lab.save();print(json.dumps({'regression':name,'ignored':ignored,'exit':r['code']}),flush=True)
  lab.check('rm -f '+lab.stage+'/'+filename)

host='cdn.kernel.org';ip=socket.getaddrinfo(host,443,socket.AF_INET,socket.SOCK_STREAM)[0][4][0]
url='https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.12.112.tar.xz'
nodes=json.loads(Path('work/stealth-ny-plus-private/selected-nodes.json').read_text())[:2]
assert len({n['entry_ip']for n in nodes})==2,'use distinct advertised entry IPs'
with Lab('travel-decision-live-20261105-private',{'new':BIN/'live','launch':Path('work/stealth-deep-private/launch.elf')},budget=900,sample_cap=25,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode())
 lab.report.update(target={'host':host,'ip':ip,'url':url},selected_nodes=nodes,sessions=[],scope='router-originated authenticated HTTPS ranges through real Proton endpoints; existing key unchanged; sequential user/kernel tunnels; no account refresh or key rotation')
 def download(interface,size,cap=25):
  args=['curl','-4','--http1.1','--resolve',host+':443:'+ip,'--range','0-'+str(size-1),'--max-filesize',str(size),'--connect-timeout','4','--max-time',str(cap),'--dump-header',lab.stage+'/headers','-fsS','-o','/dev/null','-w','%{json}']
  if interface:args+=['--interface',interface]
  args+=[url];r=lab.run(' '.join(map(shlex.quote,args)),cap+5)
  try:d=json.loads(r['stdout'])
  except ValueError:d={}
  headers={}
  for line in lab.read(lab.stage+'/headers').splitlines():
   if ':' in line:
    k,v=line.split(':',1)
    if k.lower() in ['content-range','content-length','retry-after']:headers[k.lower()]=v.strip()
  row={'requested_bytes':size,'exit':r['code'],'http_code':d.get('http_code'),'bytes':d.get('size_download'),'seconds':d.get('time_total'),'Mbps':d.get('speed_download',0)*8/1e6,'ssl_verify_result':d.get('ssl_verify_result'),'headers':headers,'error':r['stderr'][-400:]}
  row['valid']=row['exit']==0 and row['http_code']==206 and row['bytes']==size and row['ssl_verify_result']==0 and headers.get('content-range','').startswith('bytes 0-'+str(size-1)+'/')
  return row
 def stats():
  if not lab.pid:return None
  r=lab.run('cat /proc/'+str(lab.pid)+'/stat; grep -E "VmRSS|VmHWM" /proc/'+str(lab.pid)+'/status; cat /sys/class/thermal/thermal_zone0/temp')
  if r['code']:return None
  lines=r['stdout'].splitlines();f=lines[0].rsplit(') ',1)[1].split();return {'cpu_ticks':int(f[11])+int(f[12]),'rss_kib':{k:int(v)for k,v in re.findall(r'(VmRSS|VmHWM):\s+(\d+)',r['stdout'])},'temperature_millic':int(lines[-1])}
 def start(node,proto,flags):
  lab.stop()
  port=lab.udp_port if proto=='udp' else lab.tls_port
  config='[Interface]\nPrivateKey='+lab.private+'\nAddress=10.2.0.2/32\nMTU=1280\n[Peer]\nPublicKey='+node['public_key']+'\nEndpoint='+node['entry_ip']+':'+str(port)+'\nAllowedIPs=0.0.0.0/0, ::/0\nPersistentKeepalive=25\n'
  lab.put('config',config.encode());args=[lab.stage+'/launch',lab.stage+'/new',lab.stage+'/config',proto+':'+flags,lab.ifname]
  lab.pid=int(lab.check('BENCH_BUFFERS=128 '+' '.join(map(shlex.quote,args))+' >'+lab.stage+'/phase.log 2>&1 </dev/null & echo $!').strip())
  limit=time.monotonic()+17
  while time.monotonic()<limit:
   log=lab.read(lab.stage+'/phase.log')
   if 'READY' in log:
    lab.check('ip addr add 10.2.0.2/32 dev '+lab.ifname+'; ip -4 route add default dev '+lab.ifname+' table 19943; ip -4 rule add priority 19943 oif '+lab.ifname+' lookup 19943');return True
   if lab.run('kill -0 '+str(lab.pid))['code']:return False
   time.sleep(.2)
  return False
 def kernel_start(node):
  lab.stop();assert lab.run('test -d /sys/module/wireguard')['code']==0,'do not install or load missing software'
  cfg='[Interface]\nPrivateKey='+lab.private+'\n[Peer]\nPublicKey='+node['public_key']+'\nEndpoint='+node['entry_ip']+':'+str(lab.udp_port)+'\nAllowedIPs=0.0.0.0/0\nPersistentKeepalive=25\n';lab.put('wg.conf',cfg.encode())
  lab.check('ip link add '+lab.kifname+' type wireguard; wg setconf '+lab.kifname+' '+lab.stage+'/wg.conf; ip link set '+lab.kifname+' mtu 1280 up; ip addr add 10.2.0.2/32 dev '+lab.kifname+'; ip -4 route add default dev '+lab.kifname+' table 19944; ip -4 rule add priority 19944 oif '+lab.kifname+' lookup 19944')
  return True
 lab.report['direct_before']=download(None,12000000);lab.save();print(json.dumps({'direct_control':lab.report['direct_before']}),flush=True)
 assert lab.report['direct_before']['valid'],'origin control failed; do not use it for comparisons'
 modes=[('kernel','udp',None),('buffered','stealth','compact,in-place'),('unbuffered','stealth','unbuffered,compact,in-place'),('batch-offload','udp','batch,offload,compact,in-place'),('uring-offload','udp','uring,offload,compact,in-place'),('tcp','tcp','compact,in-place')]
 stopped=False
 for round_id in range(3):
  for node in (nodes if round_id%2==0 else nodes[::-1]):
   for label,proto,flags in (modes if round_id%2==0 else modes[::-1]):
    if time.monotonic()+55>lab.deadline:stopped=True;break
    row={'server':node['name'],'entry_ip':node['entry_ip'],'variant':label,'protocol':proto,'flags':flags,'round':round_id,'samples':[]};lab.report['sessions'].append(row);lab.save()
    print(json.dumps({'live_start':node['name'],'variant':label,'round':round_id}),flush=True)
    row['connected']=kernel_start(node) if label=='kernel' else start(node,proto,flags)
    if row['connected']:
     iface=lab.kifname if label=='kernel' else lab.ifname
     row['cold']=download(iface,500000,8);lab.save()
     time.sleep(4)
     sizes=[12000000,50000000] if proto=='stealth' else [50000000]
     if round_id%2:sizes.reverse()
     for size in sizes:
      before=stats();sample=download(iface,size);after=stats()
      if before and after:sample['process_cpu_ns_per_byte']=(after['cpu_ticks']-before['cpu_ticks'])*1e7/sample['bytes']if sample['bytes'] else None
      sample.update(before=before,after=after);row['samples'].append(sample);lab.save()
      if sample['http_code']==429:stopped=True;break
     if label=='kernel':row['handshake_verified']=int(lab.check('wg show '+lab.kifname+' latest-handshakes').split()[-1])>0
     else:row['diagnostics']=lab.read(lab.stage+'/phase.log')
    else:row['diagnostics']=lab.read(lab.stage+'/phase.log')
    print(json.dumps({'live_done':node['name'],'variant':label,'round':round_id,'connected':row['connected'],'samples':[{k:s.get(k)for k in ['requested_bytes','valid','Mbps','exit','http_code']}for s in row['samples']]}),flush=True)
    lab.stop();lab.save()
    if stopped:break
   if stopped:break
  if stopped:break
 lab.report['bounded_stop']=stopped
 if time.monotonic()+20<lab.deadline:lab.report['direct_after']=download(None,12000000)
 lab.save()
