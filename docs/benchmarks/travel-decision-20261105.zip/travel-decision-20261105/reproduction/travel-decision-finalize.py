import collections,hashlib,json,pathlib,re,statistics,zipfile
OUT=pathlib.Path('outputs/travel-decision-20261105');OUT.mkdir(exist_ok=True)
def read(name):return json.loads(pathlib.Path('work/travel-decision-'+name+'-20261105-private/evidence.json').read_text())
base=json.loads((OUT/'analysis.json').read_text())
cohorts={n:read(n)for n in ['controlled','regressions','live','bridge','uring-diagnostic','pgo-regressions','overflow-regression','uring-fixed-live','kernel-readiness']}
assert all(all(c['cleanup'].values())for c in cohorts.values()),'cleanup must finish and pass'
bridge=cohorts['bridge'];idx={(r['protocol'],r['round'],r['build']):r for r in bridge['samples']};bs=[]
for proto in ['udp','tcp','stealth']:
 vals=[100*(idx[proto,n,'production']['rows'][0]['Mbps']/idx[proto,n,'new']['rows'][0]['Mbps']-1)for n in range(12)]
 bs.append({'protocol':proto,'paired_median_production_vs_reference_pct':statistics.median(vals),'pairs':12,'min':min(vals),'max':max(vals)})
assert all(s['code']==0 for s in bridge['samples'])
def summary(j):
 groups=collections.defaultdict(list)
 for s in j.get('sessions',[]):
  for r in s.get('samples',[]):groups[s['server'],s['variant'],r['requested_bytes']].append(r)
 result=[]
 for (server,variant,size),a in groups.items():
  valid=[r for r in a if r['valid']]
  result.append({'server':server,'variant':variant,'bytes':size,'successes':len(valid),'attempts':len(a),'median_Mbps':statistics.median(r['Mbps']for r in valid)if valid else None,'min_Mbps':min(r['Mbps']for r in valid)if valid else None,'max_Mbps':max(r['Mbps']for r in valid)if valid else None})
 return result
def test_count(j):return sum(int(m)for r in j['tests']for m in re.findall(r'test result: ok\. (\d+) passed',r['stdout']))
live_idx={(s['server'],s['round'],s['variant']):s for s in cohorts['live']['sessions']};tls_pairs=[]
for node in ['US-NY#601','US-NY#505']:
 for size in [12000000,50000000]:
  speed=[];cpu=[]
  for n in range(3):
   a=next(x for x in live_idx[node,n,'unbuffered']['samples']if x['requested_bytes']==size);b=next(x for x in live_idx[node,n,'buffered']['samples']if x['requested_bytes']==size)
   assert a['valid']and b['valid'];speed.append(100*(a['Mbps']/b['Mbps']-1));cpu.append(100*(a['process_cpu_ns_per_byte']/b['process_cpu_ns_per_byte']-1))
  tls_pairs.append({'server':node,'bytes':size,'pairs':3,'speed_pct':statistics.median(speed),'client_cpu_per_byte_pct':statistics.median(cpu),'speed_pairs_pct':speed})
out={'bridge':bs,'baseline_regressions':test_count(cohorts['regressions']),'pgo_regressions':test_count(cohorts['pgo-regressions']),'main_live':summary(cohorts['live']),'diagnostic_live':summary(cohorts['uring-diagnostic']),'corrected_live':summary(cohorts['uring-fixed-live']),'kernel_readiness':summary(cohorts['kernel-readiness']),'live_tls_pairs':tls_pairs,'cleanup':{n:c['cleanup']for n,c in cohorts.items()},'regression_overflow':cohorts['overflow-regression']['tests']}
(OUT/'FINAL-ANALYSIS.json').write_text(json.dumps(out,indent=2))
e=OUT/'evidence';e.mkdir(exist_ok=True)
for n,c in cohorts.items():
 # Evidence never contains account credentials or WireGuard private configuration.
 text=json.dumps(c,indent=2)
 assert not re.search(r'PrivateKey\s*=|Authorization:\s*Bearer|"(?:access_token|refresh_token|password)"\s*:',text,re.I),'do not publish secrets'
 (e/(n+'.json')).write_text(text)
for p in pathlib.Path('work/travel-decision-uring-diagnostic-20261105-private').glob('fdinfo*.txt'):(e/p.name).write_bytes(p.read_bytes())
reg=cohorts['overflow-regression']['tests'];assert reg[0]['code']==101 and reg[1]['code']==0 and reg[2]['code']==0
fixed=out['corrected_live'];lines=[]
lines+=['ProtunNext Travel rerun — November 4, 2026 New York / November 5 UTC','',
'The measurements support compact pools and in-place crypto; Linux mmsg with outer UDP offloads; and unbuffered Stealth for this Travel router and Linux x64. Keep the tested TUN aggregation and io_uring prototypes out of the production default. Do not make parallel crypto or PGO mandatory from these measurements. The router run found a real io_uring completion-overflow liveness bug and verified a minimal experimental correction. No production backend, main branch or PR was changed.',
'',
'Travel is one physical two-core Cortex-A53 ARM64 router running Linux 6.12.112. io_uring was enabled and actually exercised. Native ARM64 kernel 6.18 remains unmeasured. Twelve repeated rounds on this router are not twelve independent devices. The main full-worker bulk comparisons use balanced AB/BA order; supplementary latency, oversized, memory, batch-size, TLS 1.2 and TUN cases use fixed order. Raw results retain outliers and failures.',
'',
'The controlled worker uses the actual Connection API, TUN, WireGuard encryption and authenticated UDP/TCP/TLS peer. The application is IPv4 UDP request/reply; every response validates payload, sequence, length and duplication. This is not an HTTPS or NIC forwarding benchmark. Whole-process RSS includes the peer and generator, whereas worker CPU is measured for the client thread at 100 Hz. Short timings and a two-core shared system produce wide throughput spreads; CPU/byte trends are often more consistent. Percentages from separate changes are not additive.',
'',
'Completed: 396 main/supplementary timed worker samples; 48 held-out PGO comparisons (24 pairs); 600 fresh Stealth starts; three concurrent 600-second protocol soaks; 72 PR-source bridge samples; 56 baseline and 56 profile-used regression test executions. These are repeated executions, not counts of unique tests. All completed successfully. Both TLS versions, UDP offloads and io_uring activation were recorded. The three simultaneous soaks each observed five handshake responses and zero invalid packets; their throughput is unsuitable for ranking because they compete for two cores. Component results include 80 UDP cases, 128 TLS rows, 39 crypto/pool rows, 36 shared-session parallel-crypto rows and eight TUN-boundary rows. Four pilot worker samples and six PGO training cases are retained separately.',
'',
'The main Proton comparison contains 36 sequential tunnel sessions, 48 bulk downloads and separate cold requests. It uses the existing account/key unchanged, two distinct saved Plus endpoints (US-NY#601 and US-NY#505), interface-bound temporary routing and verified HTTPS ranges from one pinned cdn.kernel.org IPv4 address. Stealth uses 12 MB and 50 MB files, other protocols 50 MB; three rounds reverse server/configuration and file order. Successful downloads require exit 0, HTTP 206, exact length and Content-Range, and successful TLS verification. Partial transfers are failures, never throughput samples. The origin file was linux-6.12.112.tar.xz. This tests the NoLocalAgent transport path, not full account/Plus-control-plane parity.',
'',
'The controlled near-MTU table uses 1,200 application bytes, window 32 and paired medians. Positive CPU/RSS percentages mean higher cost.',
'',
'| Change, matched otherwise | Throughput | Worker CPU / byte | Whole-test peak RSS |',
'|---|---:|---:|---:|']
for comp,proto,label in [('mmsg-only','udp','mmsg alone'),('compact-copy','udp','Compact versus full pool, copy crypto'),('inplace-compact','udp','In-place versus copy crypto, compact pool'),('outer-offloads','udp','Outer GSO/GRO versus mmsg alone'),('uring-offload','udp','io_uring128 versus mmsg, both with offloads (original)'),('unbuffered-TLS13','stealth','Unbuffered versus buffered Stealth, TLS 1.3'),('unbuffered-TLS12','stealth','Unbuffered versus buffered Stealth, TLS 1.2'),('TUN-aggregation-screening','udp','Outbound software TUN aggregation screening')]:
 r=next(x for x in base['statistics']if x['family']=='worker'and x['comparison']==comp and x['transport']==proto and x['payload']==1200 and x['window']==32)
 lines.append('| '+label+' | '+' | '.join(f'{r[k]["median"]:+.2f}%'for k in ['speed_pct','worker_cpu_pct','rss_pct'])+' |')
lines+=['',
'Compact-pool initial reservation fell 95.31%; that is reserved capacity, not a 95% runtime RSS reduction. Compact pools reduce measured RSS substantially, but in-place crypto raises whole-fixture peak RSS versus copy crypto at a fixed compact pool. Keep its CPU reduction with an explicit memory budget. TCP in-place CPU/byte fell 10.65% while throughput median changed -4.35% with wide variation; do not advertise a universal throughput gain. The batch-limit screening gives no convincing case for changing the present limit 16. mmsg reduces syscall counts, but that alone does not guarantee a throughput gain.',
'',
'The TUN comparison is screening only: raw samples run 1.5 seconds versus one second for aggregate samples, and generator sends change. The prototype is outbound software segmentation, not a complete bidirectional multiqueue pipeline. Its higher UDP worker CPU and lack of a clear worker benefit support keeping it disabled.',
'',
'The original live results below show successful-transfer medians in Mbps, with successes/attempts. Do not rank a 2/3 or 0/3 backend as reliable. The kernel failures were four-second connection timeouts with no HTTP response, whereas io_uring failures were 25-second partial-download stalls. They are distinct observations.',
'',
'| Protocol / build | US-NY#601, 50 MB | US-NY#505, 50 MB |',
'|---|---:|---:|']
def cell(rows,node,variant,size=50000000):
 r=next(r for r in rows if r['server']==node and r['variant']==variant and r['bytes']==size)
 return ('—'if r['median_Mbps']is None else f'{r["median_Mbps"]:.2f}')+f' ({r["successes"]}/{r["attempts"]})'
for variant,label in [('kernel','Kernel WireGuard UDP'),('batch-offload','Optimized mmsg WireGuard UDP'),('tcp','Optimized WireGuard TCP'),('buffered','Buffered Stealth'),('unbuffered','Unbuffered Stealth'),('uring-offload','Original io_uring UDP + offloads')]:lines.append('| '+label+' | '+cell(out['main_live'],'US-NY#601',variant)+' | '+cell(out['main_live'],'US-NY#505',variant)+' |')
lines+=['',
'All 24 Stealth bulk downloads completed. At 12 MB, buffered/unbuffered medians were 78.31/110.77 Mbps on #601 and 80.07/102.92 Mbps on #505. Paired unbuffered improvements were +41.46%/+20.00% at 12 MB and +32.96%/+25.41% at 50 MB (#601/#505); client-process CPU/byte fell approximately 23–25%. These results favor unbuffered on this router despite the smaller controlled-worker advantage. The previous router run had mixed 12 MB results; this rerun does not pool different-day measurements as matched pairs.',
'',
'Direct 12 MB controls changed from 100.37 to 201.17 Mbps during the main WAN series. That variation, three rounds per cell, cold/session effects and shared Internet paths prevent treating WAN medians as controlled hardware speed limits. Both original kernel connection failures remain recorded. No evidence here proves a cryptographic provider caused a kernel/userspace gap.',
'',
'The extra original-io_uring diagnostic separates offloads from receiver selection:',
'',
'| Original UDP backend | Successful 50 MB transfers, both servers |',
'|---|---:|']
for v in ['batch-offload','uring-no-offload','uring-offload']:
 rs=[r for r in out['diagnostic_live']if r['variant']==v];lines.append(f'| {v} | {sum(r["successes"]for r in rs)}/{sum(r["attempts"]for r in rs)} |')
lines+=['',
'The router kernel fdinfo captured an empty visible CQ, no active receive poll, and `CqOverflowList: user_data=1, res=-105, flags=0`. The terminal ENOBUFS CQE lacked F_MORE and was trapped in overflow. After draining the visible CQ, the receiver still believed its request remained active and never flushed the terminal event or rearmed. This is a real liveness defect in the expanded experimental 128-buffer receiver. It is not evidence that io_uring itself is disabled or that every earlier download failure had this cause.',
'',
'A burst regression explicitly requires real CQ overflow. Original source fails after 128 completions, enobufs=0, submissions=1. The minimal experimental correction checks CQ_OVERFLOW after draining the visible queue and invokes the crate submit path, which uses nonblocking GETEVENTS to flush pending completions. The corrected test records 353 completions, two ENOBUFS events and three submissions, then validates a new packet. All three corrected io_uring tests passed, including IPv4/IPv6 maximum payload, GRO short tail and cancellation. The CQ size and buffer count were unchanged to isolate the fix.',
'',
'A separate two-round corrected-WAN series uses the same endpoints/origin, six seconds of settling, and records kernel handshakes before bulk. It is a later cohort, not a matched fix-speed comparison against the earlier series:',
'',
'| UDP backend, corrected experiment | US-NY#601, 50 MB | US-NY#505, 50 MB |',
'|---|---:|---:|']
for v,l in [('kernel','Kernel control'),('batch-offload','mmsg + offloads control'),('uring-no-offload','Corrected io_uring without offloads'),('uring-offload','Corrected io_uring with offloads')]:lines.append('| '+l+' | '+cell(fixed,'US-NY#601',v)+' | '+cell(fixed,'US-NY#505',v)+' |')
lines+=['',
'The correction is experimental and was not deployed or merged. Even when downloads finish, original controlled io_uring performance is essentially tied on Travel with 83% greater whole-test peak RSS; the earlier x64 LTS tests measured 13.55–17.30% lower throughput. Eight corrected WAN downloads are not a long-duration or all-platform acceptance test. Keep mmsg as the Linux default; preserve the bug regression if io_uring development continues.',
'',
'The last kernel-only check allowed quiet time and retried a small readiness request before the bulk file. Both 50 MB downloads completed: #601 56.94 Mbps and #505 204.90 Mbps. #505 needed a second readiness attempt. This demonstrates that the connection failures were recoverable in this run; their underlying cause is not established. Do not combine these later one-shot numbers with the original balanced-series medians or claim a provider defect. Handshake/readiness logs and every failed attempt remain in evidence/kernel-readiness.json.',
'',
'Shared-session crypto primitive throughput at 1,280 bytes improved 74.99% with two workers and 85.98% with four; four threads oversubscribe this two-core router. Nonce/replay/tag checks passed, but no production bounded parallel packet queue, rekey/cancellation/order pipeline was benchmarked. This supports a prototype, not enabling production parallel crypto.',
'',
'Travel-native PGO used instrumented training at 256/1,000 bytes and held-out 64/1,200-byte tests with four paired rounds per protocol/size. Matching Rust LLVM tools merged the profiles. At 1,200 bytes, UDP/TCP/Stealth throughput medians were -2.50%/+6.79%/-3.56%; client-worker CPU/byte changed -0.57%/-1.14%/-8.40%. At 64 bytes, throughput changed -7.55%/-1.86%/+10.90%. All 56 profile-used regression executions passed. The profile also optimizes the peer/generator, and the control plane was not representatively trained. PGO is not justified as a universal mandatory build.',
'',
'The source bridge tests frozen PR #2 f53b963 with only a benchmark entry point added. Against frozen experiment 83f0252 with equivalent selected options, production median throughput differences were UDP -0.83%, TCP -1.41%, Stealth -2.90%, across 12 pairs each. Wide individual differences are retained. All 72 samples passed. This bridge supports relevance of the fixture to the PR hot path; it does not establish feature-parity acceptance.',
'',
'General recommendation: retain compact buffers/in-place crypto with measured memory limits and the syscall-batching implementation; select offloads and TLS using complete-worker evidence. Keep both TLS adapters until supported-platform worker acceptance permits simplification. Reject the tested software TUN aggregation and original io_uring receiver as production defaults. Prototype parallel crypto only with bounded queues, session/key-epoch correctness, latency, rekey and cancellation tests. Make PGO an optional, architecture/workload-trained build rather than a release requirement.',
'',
'| Target | Recommendation supported by current evidence | Remaining acceptance boundary |',
'|---|---|---|',
'| Linux x64, 6.12 / 6.18 LTS | mmsg + outer GSO/GRO; unbuffered Stealth candidate; compact/in-place | Prior actual-LTS worker results favor unbuffered by 48–51%; shipping integration, sustained NIC/forwarding workloads and complete feature regressions still required |',
'| Travel ARM64, 6.12.112 | mmsg + offloads; unbuffered Stealth favored for this device; keep batch limit 16 | WAN sample size is small; monitor runtime RSS and sparse-traffic latency |',
'| Other Linux ARM64, including 6.18 LTS | mmsg baseline; measure TLS per device/workload | Previous Neoverse-N2 worker lost 3.56% with unbuffered; Travel does not prove all ARM64 benefits. No native ARM64 6.18 acceptance yet |',
'| macOS 26 / 27, ARM64 | Buffered TLS remains the candidate | Prior M1 VM framing tests lost about 20–30% with unbuffered; complete Network Extension worker test remains |',
'| iOS / iPadOS 26 / 27, ARM64 | Keep buffered candidate pending device data | macOS components are not iOS/iPadOS device or Network Extension acceptance |',
'| Windows 11 25H2 / 26H2, x64 | Keep buffered pending representative worker comparison; use Windows packet APIs | Previous 26H2 framing comparisons were noisy/inconclusive; 25H2 runtime and full worker remain unmeasured |',
'| Android 16 / 17, 16 KB target | Keep current adapter until native application measurements; use protected/bound sockets | No Android native app performance acceptance; ARM64 Linux results are not VpnService results |',
'',
'These are performance decisions for tested candidates, not a claim that every platform, account operation, Plus feature, network transition or deployment scenario has passed. Do not erase fallback/cancellation/MTU correctness merely because older OS versions are dropped. Kernel TLS remains outside the requested implementation scope.',
'',
'All router stages have completed their guarded cleanup. Saved configuration, routes/rules/default path, packages, socket limits, interfaces, boot/netifd identity and Direct mode matched their snapshots. Only our own temporary stage files/interfaces/rules were removed. No installed software was removed, no key was rotated, and Home was not accessed. Independent final checks are in postflight.json. Local evidence/build artifacts remain on the laptop.',
'',
'Official contracts used to check the diagnosis and methodology: [liburing CQ overflow](https://github.com/axboe/liburing/blob/master/man/io_uring_cq_has_overflow.3), [liburing event flushing](https://github.com/axboe/liburing/blob/master/man/io_uring_get_events.3), [multishot recvmsg and F_MORE](https://github.com/axboe/liburing/blob/master/man/io_uring_prep_recvmsg.3), [Linux 6.12 fdinfo implementation](https://github.com/torvalds/linux/blob/v6.12/io_uring/fdinfo.c), [Linux segmentation offloads](https://www.kernel.org/doc/html/v6.12/networking/segmentation-offloads.html), [Rust PGO procedure](https://doc.rust-lang.org/rustc/profile-guided-optimization.html). These documents establish API behavior; measured performance comes from the attached raw results, not the documentation.',
'',
'Evidence: analysis.json and PAIRED-RESULTS.md contain all controlled per-round comparisons; FINAL-ANALYSIS.json summarizes WAN, regressions, bridge and cleanup; evidence/*.json retains raw stdout, counters, failures, source/binary fingerprints and timing. `uring-before.rs`, `uring-after.rs`, `overflow-regression.rs` and the patch retain the exact experimental receiver change. Previous CI evidence remains in ../decision-hour-20261104/RESULTS.md and is not silently replaced by this device rerun.']
(OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n')
for n in ['uring-before.rs','uring-after.rs','overflow-regression.rs']:(e/n).write_bytes((pathlib.Path('work/travel-decision-binaries')/n).read_bytes())
(e/'uring-test-before.rs').write_text((e/'uring-before.rs').read_text()+(e/'overflow-regression.rs').read_text())
import difflib
(e/'uring-overflow-fix.patch').write_text(''.join(difflib.unified_diff((e/'uring-before.rs').read_text().splitlines(True),(e/'uring-after.rs').read_text().splitlines(True),fromfile='experimental-before/src/uring_rx.rs',tofile='experimental-after/src/uring_rx.rs')))
(e/'uring-fix-only.patch').write_text(''.join(difflib.unified_diff((e/'uring-test-before.rs').read_text().splitlines(True),(e/'uring-after.rs').read_text().splitlines(True),fromfile='experimental-before/src/uring_rx.rs',tofile='experimental-after/src/uring_rx.rs')))
print(json.dumps({'live':out['main_live'],'corrected_live':fixed,'regressions':[out['baseline_regressions'],out['pgo_regressions']],'all_cleanup':True},indent=2))
