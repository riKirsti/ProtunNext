import ast,hashlib,json,pathlib,re,shlex,sys,time
sys.path.insert(0,'work')
from stealth_router_lab import Lab
B=pathlib.Path('work/travel-decision-binaries')
assert all(json.loads(pathlib.Path('work/travel-decision-overflow-regression-20261105-private/evidence.json').read_text())['cleanup'].values())
original=json.loads(pathlib.Path('work/travel-decision-live-20261105-private/evidence.json').read_text());host=original['target']['host'];ip=original['target']['ip'];url=original['target']['url'];nodes=original['selected_nodes']
tree=ast.parse(pathlib.Path('work/travel-decision-followup.py').read_text())
for block in tree.body:
 if isinstance(block,ast.With):
  for f in block.body:
   if isinstance(f,ast.FunctionDef)and f.name in ['download','stats','start','kernel_start']:exec(compile(ast.Module(body=[f],type_ignores=[]),'<same live-test helpers>','exec'))
assert hashlib.sha256((B/'livefixed').read_bytes()).digest()!=hashlib.sha256((B/'live').read_bytes()).digest(),'must use corrected binary'
with Lab('travel-decision-uring-fixed-live-20261105-private',{'new':B/'livefixed','launch':pathlib.Path('work/stealth-deep-private/launch.elf')},budget=600,sample_cap=25,expected_mode='direct') as lab:
 lab.put('cleanup.sh',re.sub(r'^rm -f .*$', 'rm -f "$stage/"*',lab.read(lab.stage+'/cleanup.sh'),flags=re.M).encode())
 lab.report.update(target=original['target'],sessions=[],scope='experimental CQ-overflow flush; 2 balanced rounds; six-second settling; kernel handshake recorded before bulk; no production source change',source_sha256=hashlib.sha256((B/'uring-after.rs').read_bytes()).hexdigest())
 modes=[('kernel',''),('batch-offload','batch,offload,compact,in-place'),('uring-no-offload','uring,compact,in-place'),('uring-offload','uring,offload,compact,in-place')]
 for round_id in range(2):
  for node in (nodes if round_id==0 else nodes[::-1]):
   for label,flags in (modes if round_id==0 else modes[::-1]):
    assert time.monotonic()+45<lab.deadline
    row={'server':node['name'],'variant':label,'round':round_id,'protocol':'udp','flags':flags,'samples':[]};lab.report['sessions'].append(row);lab.save()
    row['connected']=kernel_start(node)if label=='kernel'else start(node,'udp',flags)
    if row['connected']:
     iface=lab.kifname if label=='kernel'else lab.ifname
     row['cold']=download(iface,500000,8);time.sleep(6)
     if label=='kernel':row['handshake_verified']=int(lab.check('wg show '+lab.kifname+' latest-handshakes').split()[-1])>0
     before=stats();sample=download(iface,50000000);after=stats();sample.update(before=before,after=after);row['samples'].append(sample)
    if label!='kernel':row['diagnostics']=lab.read(lab.stage+'/phase.log')
    lab.save();print(json.dumps({'fixed_server':node['name'],'variant':label,'round':round_id,'connected':row['connected'],'samples':[{k:s.get(k)for k in ['valid','Mbps','bytes','exit','error']}for s in row['samples']]}),flush=True);lab.stop()
