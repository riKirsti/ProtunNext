import datetime,hashlib,json,pathlib,re,shlex,sys
sys.path.insert(0,'work')
import router_access
names=['controlled','regressions','live','bridge','uring-diagnostic','pgo-regressions','overflow-regression','uring-fixed-live','kernel-readiness']
reports=[json.loads(pathlib.Path('work/travel-decision-'+n+'-20261105-private/evidence.json').read_text())for n in names]
assert all(all(j['cleanup'].values())for j in reports)
c=router_access.connect()
def run(cmd):
 _,o,e=c.exec_command(cmd,timeout=20);out=o.read().decode();err=e.read().decode();code=o.channel.recv_exit_status();return code,out,err
checks={}
for j in reports:
 stage=j['stage'];assert re.fullmatch(r'/tmp/pn-lab\.[A-Za-z0-9]+',stage)
 checks[stage+'_absent']=run('test ! -e '+shlex.quote(stage))[0]==0
 for key in ['interface','kernel_interface']:
  name=j[key];assert re.fullmatch(r'p[kn]l[A-Za-z0-9]+',name);checks[name+'_absent']=run('test ! -d /sys/class/net/'+name)[0]==0
 # Read only exact owned paths in executable targets and shell/guard command lines.
 cmd='for f in /proc/[0-9]*/exe; do readlink "$f" 2>/dev/null; done; for f in /proc/[0-9]*/cmdline; do tr "\\000" " " < "$f" 2>/dev/null; echo; done'
 text=run(cmd)[1];checks[stage+'_processes_absent']=stage not in text
checks['direct_mode']=run('uci -q get exitnode.main.mode')[1].strip()=='direct'
for t in [19943,19944]:
 code,out,err=run('ip -4 route show table '+str(t));checks[str(t)+'_table_empty']=not out.strip()and (code==0 or 'FIB table does not exist'in err)
checks['temporary_rules_absent']=not re.search(r'^(19943|19944):',run('ip -4 rule show')[1],re.M)
before=json.loads(pathlib.Path('work/travel-decision-extra-config-before.json').read_text())
for path,digest in before['sha256'].items():
 code,out,err=run('sha256sum '+shlex.quote(path)+' 2>/dev/null');current=out.split()[0]if code==0 else None
 checks[path+'_unchanged']=current==digest
c.close()
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'all_passed':all(checks.values()),'scope':'independent final read-only check; per-stage snapshots additionally cover saved configs, package inventories, default path, socket limits and router identity'}
p=pathlib.Path('outputs/travel-decision-20261105/postflight.json');p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['all_passed']
