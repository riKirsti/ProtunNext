"""Same PR4 matrix on Travel, using only an owned private network namespace."""
import hashlib
import importlib.util
import json
import pathlib
import re
import shlex
import socket
import sys
import time
import router_access

ROOT = pathlib.Path(__file__).resolve().parents[1]
PRIVATE = ROOT / 'work/pr4-travel-private'
OUT = ROOT / 'outputs/pr4-travel/controlled'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'work/ProtunNext/experiments/audit'))
from run import plan
from analyze import publish

c = router_access.connect()
c.get_transport().set_keepalive(10)
stage = guard = None
rows = []
checks = {}

def remote(command, timeout=20):
    _, out, err = c.exec_command('HISTFILE=/dev/null; export HISTFILE; ' + command, timeout=timeout)
    try:
        text, errors = out.read().decode(errors='replace'), err.read().decode(errors='replace')
        return dict(exit=out.channel.recv_exit_status(), stdout=text, stderr=errors)
    finally:
        out.channel.close()

def put(name, data):
    assert re.fullmatch('[a-z.-]+', name)
    i, o, e = c.exec_command('umask 077; cat > ' + stage + '/' + name + '; chmod 700 ' + stage + '/' + name, timeout=30)
    i.write(data); i.flush(); i.channel.shutdown_write(); o.read()
    assert o.channel.recv_exit_status() == 0

commands = {
 'mode':'uci -q get exitnode.main.mode',
 'identity':'cat /proc/sys/kernel/random/boot_id; pidof netifd',
 'packages':'apk info -v | sort', 'links':'ls -1 /sys/class/net | sort',
 'rules':'ip -4 rule show', 'default':'ip -4 route show default',
 'limits':'cat /proc/sys/net/core/rmem_max /proc/sys/net/core/wmem_max',
 'configs':'for f in /etc/config/exitnode /etc/config/network /etc/config/firewall /etc/config/dhcp /etc/config/wireless /root/proton-private/active.conf /root/proton-private/active.server /root/proton-private/preferences.json /root/proton-private/transport-ports.json; do if [ -f "$f" ]; then sha256sum "$f"; else echo "MISSING $f"; fi; done'
}
before = {k:remote(cmd)['stdout'] for k,cmd in commands.items()}
(PRIVATE / 'controlled-before.json').write_text(json.dumps(before, indent=2))
kernel = remote('uname -r')['stdout'].strip()
assert remote('cat /sys/devices/system/cpu/online')['stdout'].strip() == '0-1'
sources = json.loads((PRIVATE / 'builds.json').read_text())
schedule = plan()
for row in schedule:
    row['resources'] = 'client-core0;peer-and-generator-core1'
(OUT / 'plan.json').write_text(json.dumps(schedule, indent=2))

try:
    stage = remote('mktemp -d /tmp/pr4-cpu.XXXXXX')['stdout'].strip()
    assert re.fullmatch(r'/tmp/pr4-cpu\.[A-Za-z0-9]+', stage)
    started = time.monotonic()
    stop = f'''for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in {stage}/*) p=${{f%/exe}}; kill -KILL "${{p##*/}}" 2>/dev/null;; esac; done'''
    cleanup = stop + f'\nrm -f {stage}/main {stage}/erase {stage}/nsrun {stage}/sample.log {stage}/cleanup.sh\nrmdir {stage}\n'
    put('cleanup.sh', cleanup.encode())
    guard = int(remote('nohup sh -c ' + shlex.quote('sleep 600; sh ' + stage + '/cleanup.sh') + ' >/dev/null 2>&1 </dev/null & echo $!')['stdout'].strip())
    binary_hashes = {}
    for name in ['main', 'erase', 'nsrun']:
        path = ROOT / ('work/travel-decision-binaries/nsrun' if name == 'nsrun' else f'work/pr4-travel-build-{name}/aarch64-unknown-linux-musl/release/erasure-probe')
        data = path.read_bytes(); put(name, data)
        binary_hashes[name] = hashlib.sha256(data).hexdigest()
        assert remote('sha256sum ' + stage + '/' + name)['stdout'].split()[0] == binary_hashes[name]
        if name != 'nsrun':
            assert json.loads(remote(stage + '/' + name + ' identity')['stdout'])['effective_sources_sha256'] == sources[name]['effective_sources_sha256']
    assert remote(stage + '/nsrun /bin/true')['exit'] == 0
    env = dict(kernel=kernel, machine='aarch64',
               sources={n:{k:v for k,v in s.items() if k != 'path'} for n,s in sources.items()},
               binaries={n:binary_hashes[n] for n in ['main','erase']}, nsrun_sha256=binary_hashes['nsrun'],
               warm_seconds=1, measured_seconds=5, client_cpus=[0], peer_cpus=[1], load_cpus=[1],
               scope='Travel private network namespaces; client on core 0; fixed baseline peer and generator share core 1. Not WAN traffic or isolated whole-system CPU.')
    (OUT / 'environment.json').write_text(json.dumps(env, indent=2))
    for row in schedule:
        if time.monotonic() - started > 550:
            raise RuntimeError('bounded router window exhausted')
        rate = f"NEXT_RATE_PPS={row['rate_pps']} " if row['rate_pps'] else ''
        cmd = (f"NEXT_PEER_CPUS=1 NEXT_LOAD_CPUS=1 NEXT_CLIENT_CPUS=0 NEXT_WARM_SECONDS=1 NEXT_PEER_VECTORED=1 NEXT_LOAD_SHAPE={row['shape']} "
               + rate + f"{stage}/nsrun {stage}/{row['build']} client {stage}/main {row['protocol']} 1200 32 5 1 >{stage}/sample.log 2>&1")
        try:
            result = remote(cmd, 35)
        except (socket.timeout, TimeoutError):
            remote(stop)
            result = dict(exit=124, stdout='', stderr='sample timeout')
        raw = remote('cat ' + stage + '/sample.log')['stdout']
        metric = [json.loads(l[10:]) for l in raw.splitlines() if l.startswith('NEXT_JSON ')]
        record = dict(row, exit=result['exit'], stdout=raw, stderr=result['stderr'], metrics=metric)
        rows.append(record)
        (OUT / 'samples.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
        print(json.dumps(dict(sample=row['sample'], protocol=row['protocol'], build=row['build'], exit=result['exit'])), flush=True)
        if result['exit']:
            remote(stop)
finally:
    if stage:
        remote('sh ' + stage + '/cleanup.sh')
        if guard and stage + '/cleanup.sh' in remote(f'tr "\\0" " " </proc/{guard}/cmdline')['stdout']:
            remote(f'for child in $(cat /proc/{guard}/task/{guard}/children); do kill -TERM "$child" 2>/dev/null; done; kill -TERM {guard} 2>/dev/null; true')
        after = {k:remote(cmd)['stdout'] for k,cmd in commands.items()}
        (PRIVATE / 'controlled-after.json').write_text(json.dumps(after, indent=2))
        checks = {k:after[k] == value for k,value in before.items()}
        checks['stage_absent'] = remote('test ! -e ' + stage)['exit'] == 0
        checks['elapsed_seconds'] = time.monotonic() - started
        (OUT / 'restoration.json').write_text(json.dumps(checks, indent=2))
        print(json.dumps(dict(restoration=checks)), flush=True)
    c.close()

report = publish(OUT)
# Both auxiliaries share a core; flag their combined utilization as well.
by_id = {r['sample']:r for r in rows}
for block in report['blocks']:
    block['auxiliary_shared_core_limited'] = any(
        sum(r['metrics'][0][a]['cpu_seconds']/r['metrics'][0][a]['seconds'] for a in ['peer','load']) >= .85
        for r in rows if r['block'] == block['block'] and r['exit'] == 0 and r['metrics'])
    if block['auxiliary_shared_core_limited']:
        block['capacity_ranking'] = False
(OUT / 'router-analysis.json').write_text(json.dumps(report, indent=2))
assert not report['errors'], report['errors']
assert all(v for k,v in checks.items() if k != 'elapsed_seconds'), checks
