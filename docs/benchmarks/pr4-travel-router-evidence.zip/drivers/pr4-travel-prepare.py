"""Add identical temporary probe drivers to isolated baseline/candidate archives."""
import hashlib
import importlib.util
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = ROOT / 'work/ProtunNext'
OUT = ROOT / 'work/pr4-travel-private'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('prepare', REPO / 'experiments/audit/prepare.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
state = module.prepare('0dff6615a98e62397817783e8b60a0cef68afe0e', 'ae9c9e86da8509261812813c9438e7ea625e19f5')
live = subprocess.check_output(['git', 'show', 'pr3-research-20261105:experiments/audit/live.rs'], cwd=REPO).decode()
live = live.replace('    let mut start = None;', '''    let mut start = None;''')
live = live.replace('"process_cpu_ns":end-c,"seconds":t.elapsed().as_secs_f64(),"snapshot":con.snapshot()',
                    '"process_cpu_ns":end-c,"seconds":elapsed,"rss_kib":peak_rss(),"snapshot":con.snapshot()')
live = live.replace('let (c, t) = start.take().expect("start required");', 'let (c, t) = start.take().expect("start required");\n                let elapsed=t.elapsed().as_secs_f64();')
live += '''
fn peak_rss()->u64 {
 std::fs::read_to_string("/proc/self/status").unwrap().lines()
 .find(|l|l.starts_with("VmHWM:")).unwrap().split_whitespace().nth(1).unwrap().parse().unwrap()
}
'''
for name, row in state.items():
    source = pathlib.Path(row['path'])
    (source / 'src/live_probe.rs').write_text(live, encoding='utf-8')
    with (source / 'src/lib.rs').open('a', encoding='utf-8') as f:
        f.write('\n#[cfg(target_os="linux")] pub mod live_probe;\n')
    (source / 'src/bin/travel-live.rs').write_text('fn main(){protun_next::live_probe::run();}\n', encoding='utf-8')
    with (source / 'Cargo.toml').open('a', encoding='utf-8') as f:
        f.write('\n[[bin]]\nname="travel-live"\npath="src/bin/travel-live.rs"\n')
    digest = hashlib.sha256()
    for file in sorted([*source.rglob('*.rs'), *source.rglob('Cargo.toml'), *source.rglob('Cargo.lock')]):
        digest.update(file.relative_to(source).as_posix().encode() + b'\0')
        digest.update(file.read_bytes().replace(b'\r\n', b'\n') + b'\0')
    row['effective_sources_sha256'] = digest.hexdigest()
(OUT / 'builds.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
print(json.dumps({k:{'sha':v['sha'],'effective_sources_sha256':v['effective_sources_sha256']} for k,v in state.items()}))
