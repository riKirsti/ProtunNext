"""Recompute Travel tables from retained raw samples; never discard failures."""
import argparse
import json
import math
import pathlib
import statistics

ROOT = pathlib.Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--data', type=pathlib.Path, default=ROOT / 'outputs/pr4-travel')
p.add_argument('--output', type=pathlib.Path)
a = p.parse_args()
data, out = a.data, a.output or a.data
out.mkdir(parents=True, exist_ok=True)
wan = json.loads((data / 'wan/evidence.json').read_text())
high = json.loads((data / 'controlled/router-analysis.json').read_text())
low = json.loads((data / 'low-rate/router-analysis.json').read_text())
restore = json.loads((data / 'final-restoration.json').read_text())
assert all(restore.values()) and not high['errors'] and not low['errors']
assert high['observed_samples'] == 72 and low['observed_samples'] == 24
gm = lambda values: math.exp(statistics.mean(math.log(v) for v in values))
def values(rows):
    return dict(Mbps=gm([r['download']['Mbps'] for r in rows]),
                CPU_ns_per_byte=gm([r['cpu_ns_per_byte'] for r in rows]),
                CPU_core_percent=gm([r['worker']['process_cpu_ns']/1e9/r['worker']['seconds']*100 for r in rows]),
                peak_RSS_MiB=gm([r['worker']['rss_kib']/1024 for r in rows]))

results = dict(physical_target='Cudy TR3000 v1, ARM64, OpenWrt Linux 6.12.112',
               baseline='ae9c9e86da8509261812813c9438e7ea625e19f5',candidate='0dff6615a98e62397817783e8b60a0cef68afe0e',
               controlled=high,low_rate=low,wan={},restoration=restore)
successful = [r for r in wan['samples'] if r.get('valid')]
assert len(wan['samples']) == 28 and len(successful) == 26
assert all(r['download']['bytes']==100000000 and r['download']['status']==206 and r['forwarded_bytes']['in']>=100000000 for r in successful)
assert len({r['download']['sha256'] for r in successful}) == 1
results['completed_body_sha256'] = successful[0]['download']['sha256']
results['wan_failures'] = [r for r in wan['samples'] if not r.get('valid')]
lines = ['# PR4 Travel router retest', '',
         '**Recommendation: merge PR #4 for the measured Stealth CPU-efficiency improvement. Do not advertise a fixed WAN speed gain or a download-reliability fix.**', '',
         'Target: Cudy TR3000 v1 ARM64, OpenWrt Linux 6.12.112, current configured server US-NY#187. Baseline is merged PR #3 (ae9c9e8); candidate is PR #4 (0dff661). Identical temporary test drivers are added to separate archives, built in distinct directories using Rust 1.99.1, normal release thin LTO and aarch64-unknown-linux-musl. The only extra RUSTFLAGS select the linker flavor. Actual on-router binary hashes and compiled source identities are verified. No installed runtime is replaced.', '',
         '## Matched-load client CPU cost', '',
         '24 valid samples, three complete A/A + ABBA/BAAB blocks. All three A/A controls pass the predeclared 5% screen and every sample achieves 1,000 packets/second within 5%. Payloads are 1,200 bytes; window is 32; warmup is one second and measurement is five seconds. Both variants deliver about 9.60 Mbps by design. The client may use both router cores; the fixed baseline peer and generator share core 0. This is a cost test, not capacity. CPU is client process utilization (100% = one core); peak RSS excludes kernel and auxiliary memory.', '',
         '| Outer transport | CPU ns/byte PR3 → PR4 | Change | Client CPU % PR3 → PR4 | Peak RSS MiB PR3 → PR4 |',
         '|---|---:|---:|---:|---:|']
for b in low['blocks']:
    assert b['validity']=='usable' and b['rate_achieved']
    v=b['result']
    cells=[f"{v[k]['baseline']:.2f} → {v[k]['candidate']:.2f}" for k in ['CPU_ns_per_byte','CPU_core_percent','peak_RSS_MiB']]
    lines.append(f"| {b['protocol']} | {cells[0]} | {v['CPU_ns_per_byte']['change_percent']:+.2f}% | {cells[1]} | {cells[2]} |")
raw_low=[json.loads(l)for l in (data/'low-rate/samples.jsonl').read_text().splitlines()]
aux=max(sum(r['metrics'][0][n]['cpu_seconds']/r['metrics'][0][n]['seconds'] for n in ['peer','load'])for r in raw_low)
results['low_rate_max_auxiliary_combined_cores']=aux
lines += ['', f'Combined auxiliary utilization never exceeds {aux:.3f} CPU core. UDP/TCP changes are small; no optimization is claimed for those paths. Allocation sizes are unchanged, so small peak-RSS differences are not a memory-saving claim.', '',
          '## Actual HTTPS downloads', '',
          '28 planned samples; 26 completed 100 MB downloads. The first two UDP A/A samples failed during HTTPS warmup (three SSLEOFError attempts each), before the 100 MB transfer. Later runs of the same candidate succeeded. No failure cause is established. All TCP and Stealth samples and both kernel WireGuard samples completed. Completed bodies have matching SHA-256, HTTP 206, exact Content-Range and length, certificate validation, bound source interface and tunnel forwarding-counter checks. The URL is a fixed prefix of cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.12.112.tar.xz.', '',
          '| Transport | PR3 download Mbps | PR4 download Mbps | Client CPU/byte change | Throughput control |',
          '|---|---:|---:|---:|---|']
for proto in ['udp','tcp','stealth']:
    group=[r for r in wan['samples']if r['protocol']==proto and r['role']=='compare']
    assert len(group)==4 and all(r.get('valid')for r in group)
    base, candidate=values([r for r in group if r['build']=='main']),values([r for r in group if r['build']=='erase'])
    aa=[r for r in wan['samples']if r['protocol']==proto and r['role']=='aa']
    complete=len(aa)==4 and all(r.get('valid')for r in aa)
    control=None
    if complete:
        x,y=values([r for r in aa if r['slot']in[0,3]]),values([r for r in aa if r['slot']in[1,2]])
        control={k:(y[k]/x[k]-1)*100 for k in x}
    result=dict(baseline=base,candidate=candidate,change_percent={k:(candidate[k]/base[k]-1)*100 for k in base},
                control_complete=complete,control_change_percent=control)
    results['wan'][proto]=result
    flag='Incomplete: 2/4 controls failed warmup' if not complete else f"A/A {control['Mbps']:+.2f}%: exceeds 5% screen"
    lines.append(f"| {proto} | {base['Mbps']:.2f} | {candidate['Mbps']:.2f} | {result['change_percent']['CPU_ns_per_byte']:+.2f}% | {flag} |")
kernel=[r for r in wan['samples']if r['build']=='kernel'and r.get('valid')]
assert len(kernel)==2
results['kernel_reference_Mbps']=[r['download']['Mbps']for r in kernel]
lines += ['',f"Kernel WireGuard UDP reference: {kernel[0]['download']['Mbps']:.2f} and {kernel[1]['download']['Mbps']:.2f} Mbps (geometric mean {gm(results['kernel_reference_Mbps']):.2f}). These are two observations, not a universal ceiling; kernel CPU/RAM is not comparable with userspace-process columns.", '',
          'Stealth WAN client CPU/byte changes from '+f"{results['wan']['stealth']['baseline']['CPU_ns_per_byte']:.2f} to {results['wan']['stealth']['candidate']['CPU_ns_per_byte']:.2f} ns/byte. Its CPU-cost control changes {results['wan']['stealth']['control_change_percent']['CPU_ns_per_byte']:+.2f}%, within the cost screen. Its observed download increase is not accepted as a clean speedup because the throughput control fails. The 12 MB direct controls changed from "+f"{wan['direct_before']['Mbps']:.2f} to {wan['direct_after']['Mbps']:.2f} Mbps.", '',
          '## Retained high-load cohort and limits', '',
          'The original 72-sample CI-shaped matrix completed with zero invalid-data errors, but **0/9 cells pass the complete throughput/load screen** on Travel. The client was pinned to core 0 and auxiliaries shared core 1. Same-binary throughput changes range from -30.26% to +35.80%; all CPU/byte controls remain within 2.65%. None of the 10,000 pps cells maintains offered load. These measurements are retained and are not used for capacity ranking. The subsequent separately declared 1,000 pps cohort changes both offered load and CPU allocation to answer a matched-load CPU-cost question; it is not a retry until the high-load controls pass.', '',
          'Across all synthetic runs, the workload is local IPv4 UDP echo through the real worker and chosen outer protocol. This is one router, one configured Proton server, short samples and no latency/loss/IPv6 acceptance matrix. The test does not isolate all asynchronous kernel work or establish every platform performance limit. Kernel image hashes were not collected from the router.', '',
          '## General and platform-specific suggestions', '',
          '- General: retain PR4 as a small, documented buffer-erasure optimization. Preserve erasure extent/timing and current production paths. Profile framing/copy costs next in a separate change; do not infer a crypto-provider defect or select a new backend from these results.',
          '- Travel / Linux 6.12 ARM64: measured matched-load Stealth CPU cost improves 5.52%, with all cost controls passing. Keep existing mmsg, outer GSO/GRO and unbuffered userspace TLS. Maintain kernel WireGuard as the UDP reference; PR4 does not close its architectural gap.',
          '- Linux 6.12/6.18 x64: the preceding actual-kernel CI burst comparisons measured -4.51% / -6.80% Stealth CPU/byte across three allocations each; this router adds different ARM64 evidence, not a replacement for those results.',
          '- Other Linux ARM64, especially 6.18: native ARM64/Linux 7.0 CI is diagnostic only. Do not generalize this Cudy result to every ARM64 machine or claim a physical ARM64 6.18 result.',
          '- Android 16/17 ARM64: the unbuffered code path uses the same helper and native builds pass; physical-device throughput remains unmeasured. Retain current VpnService behavior and routing.',
          '- Windows 25H2/26H2 x64 and Apple 26/27 ARM64: retain the buffered adapter. It is not the optimized production path in PR4; no platform throughput gain is claimed. Cross-platform regression checks pass.', '',
          '## Restoration and prior evidence', '',
          'All three phase restoration checks pass. Final comparison against the initial pre-test state confirms Direct mode, saved configurations/account files, installed packages, policy rules, default route, interfaces, socket limits, boot/netifd identity unchanged. All owned stages are absent and no staged binaries remain running. No package, account key or installed runtime was changed. Detailed fingerprints remain private.', '',
          'CI comparison: https://github.com/riKirsti/ProtunNext/actions/runs/42104739688 ; cross-platform verification: https://github.com/riKirsti/ProtunNext/actions/runs/42104742250 . Official erasure contract: https://github.com/RustCrypto/utils/blob/zeroize-v1.9.1/zeroize/src/barrier.rs . Documentation establishes the API contract; the numbers above come from the retained executions.']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(out/'summary.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(dict(synthetic_samples=96,low_rate_controls='3/3',WAN_completed=len(successful),WAN_planned=28,restoration=all(restore.values()))))
