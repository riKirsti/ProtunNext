"""Bounded HTTPS validation via owned, narrowly scoped router forwarding rules."""
import hashlib
import http.client
import importlib.util
import ipaddress
import json
import pathlib
import re
import shlex
import socket
import ssl
import struct
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
PRIVATE = ROOT / 'work/pr4-travel-private'
OUT = ROOT / 'outputs/pr4-travel/wan'
OUT.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('wan_lab', ROOT / 'work/audit-router-rerun.py')
old = importlib.util.module_from_spec(spec)
sys.argv.append('--long')  # Existing traffic warmup: up to three 12 MB transfers.
spec.loader.exec_module(old)
iface = json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',"Get-NetIPAddress -AddressFamily IPv4 | Where-Object IPAddress -Like '192.168.7.*' | Select-Object InterfaceIndex,IPAddress | ConvertTo-Json -Compress"], text=True))
assert isinstance(iface, dict)
old.LOCAL = iface['IPAddress']
old.OUT = PRIVATE / 'wan'
old.OUT.mkdir(exist_ok=True)
old.PORT_LOW, old.PORT_HIGH, old.PORT = 21400, 21700, 21401
old.DEST = socket.gethostbyname(old.HOST)
ipaddress.IPv4Address(old.DEST)
context = ssl.create_default_context()

def download(size, cap=40):
    old.PORT += 1
    assert old.PORT <= old.PORT_HIGH
    result = dict(requested_bytes=size, valid=False, local_port=old.PORT)
    start = time.perf_counter()
    sock = None
    try:
        sock = socket.socket()
        sock.setsockopt(socket.IPPROTO_IP, 31, struct.pack('!I', iface['InterfaceIndex']))
        sock.settimeout(min(8, cap))
        sock.bind((old.LOCAL, old.PORT))
        sock.connect((old.DEST,443))
        sock = context.wrap_socket(sock, server_hostname=old.HOST)
        result.update(local=sock.getsockname(), peer=sock.getpeername(), tls=sock.version())
        sock.sendall((f'GET /pub/linux/kernel/v6.x/linux-6.12.112.tar.xz HTTP/1.1\r\nHost: {old.HOST}\r\nRange: bytes=0-{size-1}\r\nConnection: close\r\n\r\n').encode())
        response = http.client.HTTPResponse(sock)
        response.begin()
        result.update(status=response.status, content_range=response.getheader('Content-Range'))
        assert response.status == 206 and re.fullmatch(rf'bytes 0-{size-1}/[0-9]+', result['content_range'] or '')
        digest = hashlib.sha256()
        buf = bytearray(1024*1024)
        received = 0
        while True:
            remaining = cap - (time.perf_counter()-start)
            assert remaining > 0, 'sample deadline'
            sock.settimeout(min(8, remaining))
            n = response.readinto(buf)
            if not n:
                break
            digest.update(memoryview(buf)[:n]); received += n
            assert received <= size
        result.update(bytes=received, sha256=digest.hexdigest(), valid=received==size and result['local'][0]==old.LOCAL and result['peer'][0]==old.DEST)
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        if sock:
            sock.close()
    result['seconds'] = time.perf_counter()-start
    if result['valid']:
        result['Mbps'] = size*8/result['seconds']/1e6
    return result

old.download = download
sources = json.loads((PRIVATE / 'builds.json').read_text())
old.BASE = ROOT / 'work'

class Lab(old.Lab):
    def setup(self):
        self.c = old.router_access.connect()
        self.c.get_transport().set_keepalive(10)
        self.before = self.snapshot()
        assert self.before['mode'].strip() == 'direct'
        assert not re.search(r'^19943:', self.before['rules'], re.M)
        assert not self.run('ip -4 route show table 19943')['stdout'].strip()
        assert '10.2.0.2/' not in self.check('ip -o addr show')
        self.config = self.check('cat /root/proton-private/active.conf')
        def field(key):
            return re.search(r'^\s*'+key+r'\s*=\s*(.*?)\s*$', self.config, re.M).group(1)
        self.address = field('Address').split(',')[0].strip()
        assert self.address == '10.2.0.2/32'
        self.mtu = int(field('MTU')) if re.search(r'^MTU\s*=', self.config, re.M) else 1280
        self.endpoint = field('Endpoint')
        ipaddress.IPv4Address(self.endpoint.rsplit(':',1)[0])
        route = self.check('ip -4 route get ' + self.endpoint.rsplit(':',1)[0])
        self.bind_device = re.search(r'\bdev\s+(\S+)', route).group(1)
        assert re.fullmatch(r'[A-Za-z0-9_.-]{1,15}', self.bind_device)
        self.udp = int(self.endpoint.rsplit(':',1)[1])
        self.tls = int(json.loads(self.check('cat /root/proton-private/transport-ports.json'))['tls_ports'][0])
        self.stage = self.check('mktemp -d /tmp/pna-prfour.XXXXXX').strip()
        assert re.fullmatch(r'/tmp/pna-prfour\.[A-Za-z0-9]+', self.stage)
        self.token = 'pna' + self.stage.rsplit('.',1)[1]
        self.ifname = self.token
        assert len(self.ifname) < 15
        self.start = time.monotonic()
        self.deadline = self.start + 600
        cleanup = f'''#!/bin/sh
stage={shlex.quote(self.stage)}
for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in "$stage"/*) p=${{f%/exe}}; kill -TERM "${{p##*/}}" 2>/dev/null;; esac; done
sleep 0.2
for f in /proc/[0-9]*/exe; do x=$(readlink "$f" 2>/dev/null); case "$x" in "$stage"/*) p=${{f%/exe}}; kill -KILL "${{p##*/}}" 2>/dev/null;; esac; done
for h in $(nft -a list chain inet fw4 forward 2>/dev/null | awk -v mark={self.token} 'index($0,mark){{for(i=1;i<NF;i++)if($i=="handle" && $(i+1)~/^[0-9]+$/)print $(i+1)}}'); do nft delete rule inet fw4 forward handle "$h"; done
nft delete table ip {self.token} 2>/dev/null
ip -4 rule del priority 19943 from {old.LOCAL}/32 to {old.DEST}/32 ipproto tcp sport {old.PORT_LOW}-{old.PORT_HIGH} lookup 19943 2>/dev/null
ip -4 route del default dev {self.ifname} table 19943 2>/dev/null
ip link del dev {self.ifname} 2>/dev/null
rm -f "$stage/main" "$stage/erase" "$stage/config" "$stage/kernel.conf" "$stage/guard.sh" "$stage/cleanup.sh"
rmdir "$stage"
'''
        self.put('cleanup.sh', cleanup.encode())
        self.put('guard.sh', f'sleep 600\nsh {self.stage}/cleanup.sh\n'.encode())
        self.guard = int(self.check(f'nohup sh {self.stage}/guard.sh >/dev/null 2>&1 </dev/null & echo $!').strip())
        self.put('config', self.config.encode())
        self.report.update(kernel=self.check('uname -r').strip(), before=self.before, stage=self.stage,
                           server=self.check('cat /root/proton-private/active.server').strip(), mtu=self.mtu,
                           interface=self.ifname, method='laptop HTTPS; socket-bound interface; owned router policy/NAT only')
        self.report['binaries'] = {}
        for name in ['main','erase']:
            binary = ROOT / f'work/pr4-travel-build-{name}/aarch64-unknown-linux-musl/release/travel-live'
            data = binary.read_bytes(); self.put(name, data, 0o700)
            value = hashlib.sha256(data).hexdigest()
            assert self.check(f'sha256sum {self.stage}/{name}').split()[0] == value
            self.report['binaries'][name] = value
        # The inherited identity check reads only this two-entry local manifest.
        old_manifest = PRIVATE / 'live-builds.json'
        old_manifest.write_text(json.dumps(sources))
        self.report['kernel_already_available'] = self.run('test -d /sys/module/wireguard && command -v wg')['exit'] == 0
        self.save()
    def start_worker(self, build, proto):
        # Same owned interface/forwarding sequence as the previously audited lab.
        self.stop()
        if build == 'kernel':
            cfg = '\n'.join(line for line in self.config.splitlines() if not re.match(r'\s*(Address|MTU|DNS)\s*=', line))+'\n'
            self.put('kernel.conf', cfg.encode())
            self.check(f'ip link add {self.ifname} type wireguard')
            self.check(f'wg setconf {self.ifname} {self.stage}/kernel.conf')
            self.check(f'ip address add {self.address} dev {self.ifname}')
            self.check(f'ip link set {self.ifname} mtu {self.mtu} up')
        else:
            port = self.udp if proto == 'udp' else self.tls
            self.input, self.worker, self.error = self.c.exec_command(f'{self.stage}/{build} {self.stage}/config {proto} {self.ifname} {self.bind_device} {port}', timeout=20)
            self.channel = self.worker.channel
            assert json.loads(self.line('LIVE_READY '))['effective_sources_sha256'] == sources[build]['effective_sources_sha256']
        self.forward()

lab = Lab()
try:
    lab.setup()
    lab.report['direct_before'] = download(12000000)
    for proto in ['udp','tcp','stealth']:
        for role, order in [('aa',['erase']*4), ('compare',['main','erase','erase','main'])]:
            for slot, build in enumerate(order):
                lab.sample(build, proto, role, slot, 100000000)
    if lab.report['kernel_already_available']:
        for slot, build in enumerate(['main','kernel','kernel','main']):
            lab.sample(build, 'udp', 'kernel-control', slot, 100000000)
    lab.report['direct_after'] = download(12000000)
except BaseException as error:
    lab.report['fatal'] = type(error).__name__ + ': ' + str(error)
    lab.save()
    print(json.dumps(dict(fatal=lab.report['fatal'])), flush=True)
finally:
    lab.close()
    # Publish no saved-configuration fingerprints or private key material.
    public = {k:v for k,v in lab.report.items() if k not in ['before','stage','interface']}
    public['sources'] = {k:{a:b for a,b in v.items() if a != 'path'} for k,v in sources.items()}
    (OUT / 'evidence.json').write_text(json.dumps(public, indent=2), encoding='utf-8')
    if lab.stage:
        assert lab.report.get('cleanup') and all(lab.report['cleanup'].values()), 'restoration verification failed'
